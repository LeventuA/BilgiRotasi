#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
import zipfile

REPO = Path('/workspaces/BilgiRotasi')
ZIP_NAME = 'BilgiRotasi_AnaSayfa_Kart_Temizligi_Paketi.zip'
INSTALLER_NAME = 'BILGI_ROTASI_ANA_SAYFA_KART_TEMIZLIGI_KUR.py'

OLD_VERSION = '1.58.0+79'
NEW_VERSION = '1.59.0+80'
OLD_VERSION_NAME = '1.58.0'
NEW_VERSION_NAME = '1.59.0'
OLD_BUILD = '79'
NEW_BUILD = '80'
OLD_ARTIFACT_VERSION = '1.58.0-79'
NEW_ARTIFACT_VERSION = '1.59.0-80'

HELPER_FILE = r'''import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeSavedGamePolicy {
  HomeSavedGamePolicy._();

  static const List<String> _positiveTokens = <String>[
    'saved_game',
    'savedgame',
    'current_game',
    'currentgame',
    'game_state',
    'gamestate',
    'resume_game',
    'resumegame',
    'active_game',
    'activegame',
    'board_game',
    'boardgame',
    'saved_session',
    'gamemodel',
    'oyun',
    'tahta',
    'kayit',
    'kayıt',
  ];

  static const List<String> _negativeTokens = <String>[
    'daily',
    'gunluk',
    'günlük',
    'gorev',
    'görev',
    'duel',
    'düello',
    'league',
    'profile',
    'auth',
    'theme',
    'setting',
    'firebase',
    'token',
  ];

  static Future<bool> hasSavedGame() async {
    final prefs = await SharedPreferences.getInstance();
    final entries = <String, Object?>{};

    for (final key in prefs.getKeys()) {
      entries[key] = prefs.get(key);
    }

    return hasSavedGameFromEntries(entries);
  }

  static bool hasSavedGameFromEntries(
    Map<String, Object?> entries,
  ) {
    for (final entry in entries.entries) {
      final normalizedKey = entry.key.trim().toLowerCase();
      if (!_looksLikeSavedGameKey(normalizedKey)) {
        continue;
      }

      if (_hasMeaningfulValue(entry.value)) {
        return true;
      }
    }

    return false;
  }

  static bool _looksLikeSavedGameKey(String key) {
    final hasPositive = _positiveTokens.any(key.contains);
    if (!hasPositive) {
      return false;
    }

    final hasNegative = _negativeTokens.any(key.contains);
    return !hasNegative;
  }

  static bool _hasMeaningfulValue(Object? value) {
    if (value == null) {
      return false;
    }

    if (value is bool) {
      return value;
    }

    if (value is num) {
      return value != 0;
    }

    if (value is String) {
      final normalized = value.trim().toLowerCase();
      return normalized.isNotEmpty &&
          normalized != 'false' &&
          normalized != 'null' &&
          normalized != '{}' &&
          normalized != '[]';
    }

    if (value is List || value is Map) {
      return value.toString() != '[]' && value.toString() != '{}';
    }

    return true;
  }
}

class HomeSavedGameBanner extends StatelessWidget {
  const HomeSavedGameBanner({
    super.key,
    required this.onTap,
  });

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: HomeSavedGamePolicy.hasSavedGame(),
      builder: (context, snapshot) {
        if (snapshot.data != true) {
          return const SizedBox.shrink();
        }

        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              colors: <Color>[
                Color(0xFF0EA5A4),
                Color(0xFF4338CA),
              ],
            ),
            boxShadow: const <BoxShadow>[
              BoxShadow(
                color: Color(0x22000000),
                blurRadius: 18,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Row(
                children: <Widget>[
                  Text(
                    '💾',
                    style: TextStyle(fontSize: 28),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Kayıtlı oyunun var',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                'Yarım kalan bir oyun bulundu. Buradan Oyna bölümüne geçip oyuna devam edebilirsin.',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.92),
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  height: 1.35,
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: onTap,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('Kayıtlı Oyuna Git'),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFF7D86A),
                    foregroundColor: const Color(0xFF251B45),
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                      horizontal: 18,
                    ),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
'''

HELPER_TEST = r'''import 'package:bilgi_rotasi/home_saved_game_banner.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Ana sayfa kayıtlı oyun kartı politikası', () {
    test('anlamlı kayıtlı oyun verisini algılar', () {
      expect(
        HomeSavedGamePolicy.hasSavedGameFromEntries(
          <String, Object?>{
            'saved_game': '{"players":2}',
          },
        ),
        isTrue,
      );

      expect(
        HomeSavedGamePolicy.hasSavedGameFromEntries(
          <String, Object?>{
            'tahta_oyun_kaydi': true,
          },
        ),
        isTrue,
      );
    });

    test('boş veya alakasız veriler kartı açmaz', () {
      expect(
        HomeSavedGamePolicy.hasSavedGameFromEntries(
          <String, Object?>{
            'daily_task': '{"ready":true}',
            'theme_mode': 'dark',
            'saved_game': '{}',
          },
        ),
        isFalse,
      );

      expect(
        HomeSavedGamePolicy.hasSavedGameFromEntries(
          <String, Object?>{
            'profile_name': 'Levent',
            'gunluk_gorev': 'hazir',
          },
        ),
        isFalse,
      );
    });
  });
}
'''

STATUS_MD = r'''# Bilgi Rotası – Proje Durumu

## Son Sürüm

**1.59.0+80**

## Son Tamamlanan İş

Ana sayfa üst kartları sadeleştirildi.

- **Oyuna Başla** kartı kaldırıldı.
- **Günlük Görev** kartı kaldırıldı.
- Ana sayfada bu alan artık yalnızca kayıtlı oyun tespit edilirse görünüyor.
- Kayıtlı oyun kartı, kullanıcıyı **Oyna** bölümüne yönlendiriyor.
- Kayıtlı oyun görünürlüğü için koruyucu test eklendi.
- Canlı Düello karışık kategori ve zorluk dağılımı korunuyor.
- Firestore kuralları `bilgi-rotasi-f255d` projesinde yayında.

## Sıradaki İş

- Ana sayfadaki kayıtlı oyun kartını gerçek kayıt anahtarlarıyla iki cihazda doğrulama
- Gerekirse kayıtlı oyun kartını doğrudan ilgili oyun ekranına bağlama
- Canlı Düello iki cihaz testlerinin devamı
- 20 ve 30 soruluk maçları doğrulama
- Hükmen sonuç ve geri dönme senaryolarını tekrar kontrol etme

## Dokunulmaması Gerekenler

- `assets/questions.json` içindeki doğrulanmış soru bankası
- Mevcut Google giriş ve hesap silme sistemi
- Çalışan bulut kayıt sistemi
- Çalışan normal oyun modları
- Firestore koleksiyon adları geçiş planı olmadan değiştirilmemeli

## Bilinen Durumlar

- Toplam soru sayısı: **6710**
- Gerçek iki telefonla uçtan uca test devam ediyor.
- Kayıtlı oyun kartı görünürlüğü SharedPreferences anahtarlarına göre belirleniyor.
'''


def run(args:list[str], check:bool=True)->subprocess.CompletedProcess:
    print('$', ' '.join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(text:str, old:str, new:str, label:str)->str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: beklenen metin {count} kez bulundu.')
    return text.replace(old,new,1)


def remove_known_temp_files()->None:
    for name in ('firebase-debug.log','FIREBASE_GIRIS_LINKI.txt','000_FIREBASE_GIRIS_LINKI.txt'):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start()->None:
    remove_known_temp_files()
    result = subprocess.run(['git','status','--porcelain'], cwd=REPO, check=True, text=True, capture_output=True)
    allowed = {f'?? {INSTALLER_NAME}'}
    unexpected = [line for line in result.stdout.splitlines() if line.strip() and line.strip() not in allowed]
    if unexpected:
        print('HATA: Çalışma alanında beklenmeyen değişiklik var:')
        print('\n'.join(unexpected))
        raise RuntimeError('Önce çalışma alanı temizlenmeli.')


def ensure_import(text:str)->str:
    import_line = "import 'home_saved_game_banner.dart';\n"
    if import_line in text:
        return text
    anchor = '\nclass '
    idx = text.find(anchor)
    if idx == -1:
        raise RuntimeError('main_navigation.dart içinde class başlangıcı bulunamadı.')
    return text[:idx] + import_line + text[idx:]


def leading_spaces(line:str)->int:
    return len(line) - len(line.lstrip(' '))


def find_widget_block(lines:list[str], markers:list[str])->tuple[int,int]:
    marker_lines = []
    for marker in markers:
        for idx, line in enumerate(lines):
            if marker in line:
                marker_lines.append(idx)
                break
        else:
            raise RuntimeError(f'İşaret bulunamadı: {marker}')

    marker_min = min(marker_lines)
    marker_max = max(marker_lines)
    marker_indent = min(leading_spaces(lines[idx]) for idx in marker_lines)

    for start in range(marker_min, -1, -1):
        stripped = lines[start].strip()
        if '(' not in stripped or not stripped.endswith('('):
            continue
        if leading_spaces(lines[start]) > marker_indent:
            continue

        balance = 0
        opened = False
        for end in range(start, len(lines)):
            balance += lines[end].count('(')
            balance -= lines[end].count(')')
            if lines[end].count('(') > 0:
                opened = True
            if opened and balance == 0:
                if end >= marker_max:
                    return start, end
                break

    raise RuntimeError(f'Widget bloğu bulunamadı: {markers}')


def remove_widget_block_containing(text:str, markers:list[str], label:str)->str:
    lines = text.splitlines(keepends=True)
    start, end = find_widget_block(lines, markers)
    del lines[start:end+1]
    new_text = ''.join(lines)
    if all(marker in new_text for marker in markers):
        raise RuntimeError(f'{label}: blok silinemedi.')
    return new_text


def insert_saved_game_banner(text:str)->str:
    if 'HomeSavedGameBanner(' in text:
        return text

    lines = text.splitlines(keepends=True)
    anchor_index = None
    for idx, line in enumerate(lines):
        if 'BÖLÜMLER' in line or 'Bölümler' in line:
            anchor_index = idx
            break
    if anchor_index is None:
        raise RuntimeError('BÖLÜMLER başlığı bulunamadı.')

    indent = ' ' * leading_spaces(lines[anchor_index])
    block = (
        f"{indent}const SizedBox(height: 8),\n"
        f"{indent}HomeSavedGameBanner(\n"
        f"{indent}  onTap: () => _open(\n"
        f"{indent}    context,\n"
        f"{indent}    const PlayCenterScreen(),\n"
        f"{indent}  ),\n"
        f"{indent}),\n"
        f"{indent}const SizedBox(height: 4),\n"
    )
    lines.insert(anchor_index, block)
    return ''.join(lines)


def patch_main_navigation()->None:
    path = REPO / 'lib/main_navigation.dart'
    text = path.read_text(encoding='utf-8')
    text = ensure_import(text)
    text = remove_widget_block_containing(
        text,
        ['OYUNA BAŞLA', 'Standart Tahta Oyununu Başlat'],
        'Oyuna Başla kartı',
    )
    text = remove_widget_block_containing(
        text,
        ['GÜNLÜK GÖREV', 'Günlük Göreve Başla'],
        'Günlük Görev kartı',
    )
    text = insert_saved_game_banner(text)
    path.write_text(text, encoding='utf-8')


def write_new_files()->None:
    (REPO / 'lib/home_saved_game_banner.dart').write_text(HELPER_FILE, encoding='utf-8')
    (REPO / 'test/home_saved_game_banner_test.dart').write_text(HELPER_TEST, encoding='utf-8')
    (REPO / 'BILGI_ROTASI_DURUM.md').write_text(STATUS_MD, encoding='utf-8')


def patch_versions()->None:
    pubspec = REPO / 'pubspec.yaml'
    text = pubspec.read_text(encoding='utf-8')
    text = replace_once(text, f'version: {OLD_VERSION}', f'version: {NEW_VERSION}', 'pubspec sürümü')
    pubspec.write_text(text, encoding='utf-8')

    build_info = REPO / 'lib/app_build_info.dart'
    text = build_info.read_text(encoding='utf-8')
    text = replace_once(text, f"static const String versionName = '{OLD_VERSION_NAME}';", f"static const String versionName = '{NEW_VERSION_NAME}';", 'uygulama sürümü')
    text = replace_once(text, f'static const int buildNumber = {OLD_BUILD};', f'static const int buildNumber = {NEW_BUILD};', 'uygulama yapı numarası')
    build_info.write_text(text, encoding='utf-8')

    gate = REPO / 'tools/rc1_quality_gate.py'
    text = gate.read_text(encoding='utf-8')
    text = replace_once(text, f'EXPECTED_VERSION = "{OLD_VERSION}"', f'EXPECTED_VERSION = "{NEW_VERSION}"', 'kalite kapısı sürümü')
    gate.write_text(text, encoding='utf-8')

    workflow = REPO / '.github/workflows/android-apk.yml'
    text = workflow.read_text(encoding='utf-8')
    if OLD_VERSION not in text:
        raise RuntimeError('GitHub Actions güncel sürüm satırı bulunamadı.')
    text = text.replace(OLD_VERSION, NEW_VERSION)
    if OLD_ARTIFACT_VERSION in text:
        text = text.replace(OLD_ARTIFACT_VERSION, NEW_ARTIFACT_VERSION)
    workflow.write_text(text, encoding='utf-8')


def analyze()->None:
    print('\n2/5 Dart analizi çalışıyor...', flush=True)
    command = [
        '/workspaces/flutter/bin/dart','analyze','--format','machine',
        'lib/main_navigation.dart',
        'lib/home_saved_game_banner.dart',
        'lib/app_build_info.dart',
        'test/home_saved_game_banner_test.dart',
    ]
    result = subprocess.run(command, cwd=REPO, check=False, text=True, capture_output=True)
    output = (result.stdout + result.stderr).splitlines()
    blocking = [line for line in output if line.startswith('ERROR|') or line.startswith('WARNING|')]
    info_count = sum(line.startswith('INFO|') for line in output)
    print(f'Analiz: {len(blocking)} hata/uyarı, {info_count} bilgi notu.')
    if blocking:
        print('\n'.join(blocking[:40]))
        raise RuntimeError('Dart analizi hata veya uyarı verdi.')


def run_tests()->None:
    print('\n3/5 Testler tek tek çalışıyor...', flush=True)
    tests = [
        'test/home_saved_game_banner_test.dart',
        'test/live_duel_menu_entry_test.dart',
        'test/rc1_quality_gate_test.dart',
    ]
    for test in tests:
        print(f'\nTEST: {test}', flush=True)
        cmd = ['/workspaces/flutter/bin/flutter','test',test,'--concurrency=1','--reporter','expanded']
        result = run(cmd, check=False)
        if result.returncode == 0:
            continue
        print('Test ilk denemede geçmedi; önbellek temizlenip bir kez daha deneniyor.')
        shutil.rmtree(REPO / '.dart_tool', ignore_errors=True)
        shutil.rmtree(REPO / 'build', ignore_errors=True)
        run(['/workspaces/flutter/bin/flutter','pub','get'])
        result = run(cmd, check=False)
        if result.returncode != 0:
            raise RuntimeError(f'Test başarısız: {test}')


def cleanup_package_files()->None:
    remove_known_temp_files()
    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()
    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(['git','ls-files','--error-unmatch',ZIP_NAME], cwd=REPO, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
        if tracked:
            run(['git','rm','-f',ZIP_NAME])
        else:
            archive.unlink()


def rollback()->None:
    subprocess.run(['git','reset','--hard','HEAD'], cwd=REPO, check=False)


def main()->int:
    if not REPO.is_dir():
        print('HATA: /workspaces/BilgiRotasi bulunamadı.')
        return 1

    subprocess.run(['git','config','--unset','core.hooksPath'], cwd=REPO, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for hook in ('post-checkout','pre-push'):
        (REPO / '.git/hooks' / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()
        print('1/5 Ana sayfa kart temizliği uygulanıyor...')
        patch_main_navigation()
        write_new_files()
        patch_versions()

        run(['/workspaces/flutter/bin/dart','format',
             'lib/main_navigation.dart',
             'lib/home_saved_game_banner.dart',
             'lib/app_build_info.dart',
             'test/home_saved_game_banner_test.dart'])

        analyze()
        run_tests()

        print('\n4/5 RC2 kalite kapısı çalışıyor...')
        run(['python3','tools/rc1_quality_gate.py'])
        run(['git','diff','--check'])

        cleanup_package_files()

        print('\n5/5 Commit ve push yapılıyor...')
        run(['git','add','-A'])
        staged = subprocess.run(['git','diff','--cached','--quiet'], cwd=REPO, check=False)
        if staged.returncode == 0:
            raise RuntimeError('Kaydedilecek değişiklik bulunamadı.')
        run(['git','commit','-m','Ana sayfa ust kartlarini sade lestir'])
        run(['git','push','origin','main'])

        print('\n' + '=' * 60)
        print('TAMAMLANDI')
        print('=' * 60)
        run(['git','log','-1','--oneline'])
        print('GitHub Actions yeni 1.59.0+80 APK ve AAB derlemesini otomatik başlatacak.')
        return 0
    except Exception as error:
        print(f'\nHATA: {error}')
        print('Değişiklikler güvenli biçimde geri alınıyor...')
        rollback()
        print(f'Paket geri alındı; {INSTALLER_NAME} dosyasıyla tekrar denenebilir.')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
