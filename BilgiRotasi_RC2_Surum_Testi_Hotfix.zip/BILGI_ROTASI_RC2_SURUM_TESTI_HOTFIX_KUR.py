#!/usr/bin/env python3
from __future__ import annotations

import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
ZIP_NAME = "BilgiRotasi_RC2_Surum_Testi_Hotfix.zip"
INSTALLER_NAME = "BILGI_ROTASI_RC2_SURUM_TESTI_HOTFIX_KUR.py"


def run(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    test_path = REPO / "test/rc1_quality_gate_test.dart"
    original = test_path.read_text(encoding="utf-8")

    old = """    test('RC2 sürüm bilgisi tek merkezden gelir', () {
      expect(AppBuildInfo.versionName, '1.48.5');
      expect(AppBuildInfo.buildNumber, 69);
      expect(AppBuildInfo.channel, 'RC2');
      expect(AppBuildInfo.version, '1.48.5+69');
      expect(
        AppBuildInfo.fullLabel,
        'Sürüm 1.48.5+69 • RC2',
      );
    });
"""

    new = r"""    test('RC2 sürüm bilgisi tek merkezden gelir', () {
      final pubspec = File('pubspec.yaml').readAsStringSync();
      final versionMatch = RegExp(
        r'^version:\s*([0-9]+\.[0-9]+\.[0-9]+)\+([0-9]+)\s*$',
        multiLine: true,
      ).firstMatch(pubspec);

      expect(
        versionMatch,
        isNotNull,
        reason: 'pubspec.yaml sürüm bilgisi okunamadı.',
      );

      final versionName = versionMatch!.group(1)!;
      final buildNumber = int.parse(versionMatch.group(2)!);
      final version = '$versionName+$buildNumber';

      expect(AppBuildInfo.versionName, versionName);
      expect(AppBuildInfo.buildNumber, buildNumber);
      expect(AppBuildInfo.channel, 'RC2');
      expect(AppBuildInfo.version, version);
      expect(
        AppBuildInfo.fullLabel,
        'Sürüm $version • RC2',
      );
    });
"""

    if original.count(old) != 1:
        print("HATA: Eski sürüm testi beklenen biçimde bulunamadı.")
        return 1

    try:
        test_path.write_text(
            original.replace(old, new, 1),
            encoding="utf-8",
        )

        print("1/4 Test dosyası biçimlendiriliyor...")
        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "test/rc1_quality_gate_test.dart",
        ])

        print("2/4 RC2 kalite testi çalışıyor...")
        run([
            "/workspaces/flutter/bin/flutter",
            "test",
            "test/rc1_quality_gate_test.dart",
            "--concurrency=1",
            "--reporter",
            "expanded",
        ])

        print("3/4 Kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        zip_file = REPO / ZIP_NAME
        installer_file = REPO / INSTALLER_NAME

        if zip_file.exists():
            tracked = subprocess.run(
                ["git", "ls-files", "--error-unmatch", ZIP_NAME],
                cwd=REPO,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0
            if tracked:
                run(["git", "rm", "-f", ZIP_NAME])
            else:
                zip_file.unlink()

        if installer_file.exists():
            installer_file.unlink()

        print("4/4 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])
        run([
            "git",
            "commit",
            "-m",
            "RC2 surum testini merkezi kaynaga bagla",
        ])
        run(["git", "push", "origin", "main"])

        print()
        print("=" * 58)
        print("TAMAMLANDI")
        print("=" * 58)
        run(["git", "log", "-1", "--oneline"])
        return 0

    except subprocess.CalledProcessError as error:
        print(f"HATA: Komut başarısız oldu: {error}")
        subprocess.run(
            ["git", "reset", "--hard", "HEAD"],
            cwd=REPO,
            check=False,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
