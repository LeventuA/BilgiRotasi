#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
ZIP_NAME = "BilgiRotasi_Canli_Duello_Menu_Girisi_Paketi.zip"
INSTALLER_NAME = "BILGI_ROTASI_CANLI_DUELLO_MENU_KUR.py"

OLD_VERSION = "1.56.0+77"
NEW_VERSION = "1.57.0+78"
OLD_VERSION_NAME = "1.56.0"
NEW_VERSION_NAME = "1.57.0"
OLD_BUILD = "77"
NEW_BUILD = "78"
NEW_ARTIFACT_VERSION = "1.57.0-78"

STATUS_MD = """# Bilgi Rotası – Proje Durumu

## Son Sürüm

**1.57.0+78**

## Son Tamamlanan İş

Canlı Düello, Oyna menüsüne görünür ve doğrudan açılabilir bir oyun modu olarak bağlandı.

- Oyna ekranına **Canlı Düello** kartı eklendi.
- Kart, Meydan Okuma ile Diğer Oyun Modları arasına yerleştirildi.
- Karttan Canlı Düello giriş ekranı doğrudan açılıyor.
- Menü açıklamasında gerçek rakip, BR ve 10/20/30 soru seçenekleri belirtiliyor.
- Menü bağlantısını koruyan otomatik regresyon testi eklendi.
- Firestore bağlantı, yeniden bağlanma ve hükmen sonuç kuralları
  `bilgi-rotasi-f255d` projesine dağıtıldı.
- GitHub Actions APK ve AAB dosya adları güncel sürüme bağlandı.

## Sıradaki İş

Canlı Düello gerçek iki cihaz testi:

- Yeni `1.57.0+78` APK'yı iki telefona kurma
- İki farklı Google hesabıyla 10 soruluk normal maç
- Bir telefonu 30 saniye arka planda tutup geri dönme
- Bir telefonu 60 saniyeden uzun arka planda tutup hükmen sonuç
- Bilinçli maçtan ayrılma
- Uygulamayı yeniden açıp yarım maça dönme
- Sonuç, BR ve lig değişimini iki hesapta doğrulama
- İstemci cevap doğruluğunu sunucu tarafında güçlendirme

## Dokunulmaması Gerekenler

- `assets/questions.json` içindeki doğrulanmış soru bankası
- Mevcut Google giriş ve hesap silme sistemi
- Çalışan bulut kayıt sistemi
- Çalışan normal oyun modları
- Firestore koleksiyon adları geçiş planı olmadan değiştirilmemeli

## Kullanılan Çalışma Yöntemi

- Geliştirme GitHub Codespaces üzerinden yapılıyor.
- Kullanıcı çoğunlukla telefondan çalışıyor.
- Paketler ZIP içinde Python kurulum dosyası olarak hazırlanmalı.
- ZIP GitHub ana klasörüne yüklenip Codespaces'te pull edilerek kurulmalı.
- Her paket analiz, ilgili test ve RC2 kalite kapısından geçmeli.
- Testler tek tek ve `--concurrency=1` ile çalıştırılmalı.
- Her paketin sonunda bu durum dosyası güncellenmeli.

## Bilinen Durumlar

- Toplam soru sayısı: **6710**
- Firestore kuralları Firebase projesine başarıyla dağıtıldı.
- Gerçek iki telefonla uçtan uca test henüz yapılmadı.
- İstemci cevap doğruluğunu gönderiyor; sunucu tarafı soru doğrulaması
  yayın öncesinde güçlendirilmeli.

## Son Başarılı Canlı Düello Aşamaları

1. BR ve lig altyapısı
2. Otomatik eşleştirme kuyruğu
3. Canlı Düello giriş ve rakip arama ekranları
4. Rakip bulundu ve 3-2-1 ekranı
5. Ortak soru kimlikleri
6. Cevap ve canlı ilerleme altyapısı
7. Oynanabilir soru ekranı
8. Canlı skor ve ilerleme çubukları
9. Maç sonu sonuç ekranı
10. Atomik maç sonucu
11. Tek seferlik BR ve lig güncellemesi
12. Bulut profil ve idempotent sonuç kaydı
13. Bağlantı durumu ve 60 saniyelik yeniden bağlanma
14. Hükmen galibiyet ve yenilgi
15. Yarım kalan maça geri dönme
16. Firestore kurallarının gerçek projeye dağıtılması
17. Oyna menüsüne Canlı Düello girişi
"""

MENU_TEST = r"""import 'package:bilgi_rotasi/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Canlı Düello Oyna menüsü bağlantısı', () {
    test('kart metinleri kullanıcıya modu açıkça anlatır', () {
      expect(
        PlayCenterEntryCatalog.liveDuelTitle,
        'Canlı Düello',
      );
      expect(
        PlayCenterEntryCatalog.liveDuelDescription,
        contains('gerçek bir rakiple'),
      );
      expect(
        PlayCenterEntryCatalog.liveDuelDescription,
        contains('10, 20 veya 30'),
      );
    });

    test('kart doğru Canlı Düello ekranını açar', () {
      expect(
        PlayCenterEntryCatalog.buildLiveDuelScreen(),
        isA<LiveDuelScreen>(),
      );
    });
  });
}
"""


def run(
    args: list[str],
    *,
    check: bool = True,
) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(
    text: str,
    old: str,
    new: str,
    label: str,
) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: beklenen metin {count} kez bulundu."
        )
    return text.replace(old, new, 1)


def remove_known_temp_files() -> None:
    for name in (
        "FIREBASE_GIRIS_LINKI.txt",
        "000_FIREBASE_GIRIS_LINKI.txt",
    ):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start() -> None:
    remove_known_temp_files()

    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )

    allowed = {
        f"?? {INSTALLER_NAME}",
    }
    unexpected = [
        line
        for line in result.stdout.splitlines()
        if line.strip() and line.strip() not in allowed
    ]

    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def patch_menu() -> None:
    path = REPO / "lib/main_navigation.dart"
    text = path.read_text(encoding="utf-8")

    catalog = """class PlayCenterEntryCatalog {
  PlayCenterEntryCatalog._();

  static const String liveDuelTitle = 'Canlı Düello';
  static const String liveDuelDescription =
      'Yakın BR puanındaki gerçek bir rakiple 10, 20 veya 30 '
      'soruluk canlı maç yap.';

  static Widget buildLiveDuelScreen() {
    return const LiveDuelScreen();
  }
}

"""

    if "class PlayCenterEntryCatalog" not in text:
        text = replace_once(
            text,
            "class PlayCenterScreen extends StatelessWidget {",
            catalog + "class PlayCenterScreen extends StatelessWidget {",
            "Canlı Düello menü kataloğu",
        )

    anchor = """        _HubActionCard(
          emoji: '⚡',
          title: 'Diğer Oyun Modları',
"""

    live_duel_card = """        _HubActionCard(
          emoji: '⚔️',
          title: PlayCenterEntryCatalog.liveDuelTitle,
          description:
              PlayCenterEntryCatalog.liveDuelDescription,
          accent: const Color(0xFF4338CA),
          onTap: () => _open(
            context,
            PlayCenterEntryCatalog.buildLiveDuelScreen(),
          ),
        ),
"""

    if "title: PlayCenterEntryCatalog.liveDuelTitle" not in text:
        text = replace_once(
            text,
            anchor,
            live_duel_card + anchor,
            "Canlı Düello Oyna kartı",
        )

    path.write_text(text, encoding="utf-8")


def patch_versions() -> None:
    pubspec = REPO / "pubspec.yaml"
    text = pubspec.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"version: {OLD_VERSION}",
        f"version: {NEW_VERSION}",
        "pubspec sürümü",
    )
    pubspec.write_text(text, encoding="utf-8")

    build_info = REPO / "lib/app_build_info.dart"
    text = build_info.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"static const String versionName = '{OLD_VERSION_NAME}';",
        f"static const String versionName = '{NEW_VERSION_NAME}';",
        "uygulama sürümü",
    )
    text = replace_once(
        text,
        f"static const int buildNumber = {OLD_BUILD};",
        f"static const int buildNumber = {NEW_BUILD};",
        "uygulama yapı numarası",
    )
    build_info.write_text(text, encoding="utf-8")

    gate = REPO / "tools/rc1_quality_gate.py"
    text = gate.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f'EXPECTED_VERSION = "{OLD_VERSION}"',
        f'EXPECTED_VERSION = "{NEW_VERSION}"',
        "kalite kapısı sürümü",
    )
    gate.write_text(text, encoding="utf-8")

    workflow = REPO / ".github/workflows/android-apk.yml"
    text = workflow.read_text(encoding="utf-8")

    if OLD_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions güncel sürüm satırı bulunamadı."
        )
    text = text.replace(OLD_VERSION, NEW_VERSION)

    old_artifact_version = "1.48.5-69"
    if old_artifact_version in text:
        text = text.replace(
            old_artifact_version,
            NEW_ARTIFACT_VERSION,
        )

    workflow.write_text(text, encoding="utf-8")


def write_new_files() -> None:
    test_path = REPO / "test/live_duel_menu_entry_test.dart"
    test_path.write_text(MENU_TEST, encoding="utf-8")

    status_path = REPO / "BILGI_ROTASI_DURUM.md"
    status_path.write_text(STATUS_MD, encoding="utf-8")


def analyze() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)

    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/main_navigation.dart",
        "lib/live_duel_screen.dart",
        "lib/app_build_info.dart",
        "test/live_duel_menu_entry_test.dart",
    ]

    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )

    output = (result.stdout + result.stderr).splitlines()
    blocking = [
        line
        for line in output
        if line.startswith("ERROR|")
        or line.startswith("WARNING|")
    ]
    info_count = sum(
        line.startswith("INFO|") for line in output
    )

    print(
        f"Analiz: {len(blocking)} hata/uyarı, "
        f"{info_count} bilgi notu."
    )

    if blocking:
        print("\n".join(blocking[:20]))
        raise RuntimeError(
            "Dart analizi hata veya uyarı verdi."
        )


def run_tests() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)

    tests = [
        "test/live_duel_menu_entry_test.dart",
        "test/live_duel_screen_test.dart",
        "test/live_duel_connection_test.dart",
        "test/rc1_quality_gate_test.dart",
    ]

    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]

        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print(
            "Test ilk denemede geçmedi; "
            "önbellek temizlenip bir kez daha deneniyor."
        )
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])

        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")


def cleanup_package_files() -> None:
    remove_known_temp_files()

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ZIP_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if tracked:
            run(["git", "rm", "-f", ZIP_NAME])
        else:
            archive.unlink()


def rollback() -> None:
    subprocess.run(
        ["git", "reset", "--hard", "HEAD"],
        cwd=REPO,
        check=False,
    )

    test_path = REPO / "test/live_duel_menu_entry_test.dart"
    if test_path.exists():
        tracked = subprocess.run(
            [
                "git",
                "ls-files",
                "--error-unmatch",
                "test/live_duel_menu_entry_test.dart",
            ],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if not tracked:
            test_path.unlink()


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()

        print("1/5 Canlı Düello menü girişi uygulanıyor...")
        patch_menu()
        patch_versions()
        write_new_files()

        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "lib/main_navigation.dart",
            "lib/app_build_info.dart",
            "test/live_duel_menu_entry_test.dart",
        ])

        analyze()
        run_tests()

        print("\n4/5 RC2 kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        cleanup_package_files()

        print("\n5/5 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])

        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError(
                "Kaydedilecek değişiklik bulunamadı."
            )

        run([
            "git",
            "commit",
            "-m",
            "Canli duelloyu Oyna menusune ekle",
        ])
        run(["git", "push", "origin", "main"])

        print("\n" + "=" * 60)
        print("TAMAMLANDI")
        print("=" * 60)
        run(["git", "log", "-1", "--oneline"])
        print(
            "GitHub Actions yeni 1.57.0+78 APK ve AAB "
            "derlemesini otomatik başlatacak."
        )
        return 0

    except Exception as error:
        print(f"\nHATA: {error}")
        print(
            "Değişiklikler güvenli biçimde geri alınıyor..."
        )
        rollback()
        print(
            f"Paket geri alındı; {INSTALLER_NAME} "
            "dosyasıyla tekrar denenebilir."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
