#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"
ARCHIVE_NAME = 'BilgiRotasi_Canli_Duello_Atomik_Sonuc_Paketi.zip'
INSTALLER_NAME = 'BILGI_ROTASI_CANLI_DUELLO_ATOMIK_SONUC_KUR.py'


def run(command: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    print("$", " ".join(command), flush=True)
    return subprocess.run(command, cwd=REPO, check=check)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: beklenen metin {count} kez bulundu.")
    return text.replace(old, new, 1)


def replace_between(
    text: str,
    start_marker: str,
    end_marker: str,
    replacement: str,
    label: str,
) -> str:
    start = text.find(start_marker)
    if start < 0:
        raise RuntimeError(f"{label}: başlangıç bulunamadı.")
    end = text.find(end_marker, start)
    if end < 0:
        raise RuntimeError(f"{label}: bitiş bulunamadı.")
    return text[:start] + replacement + text[end:]


def read_payload(relative: str) -> str:
    path = PAYLOAD / relative
    if not path.is_file():
        raise RuntimeError(f"Paket dosyası eksik: {relative}")
    return path.read_text(encoding="utf-8")


def write_repo(relative: str, content: str) -> None:
    path = REPO / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def ensure_clean_start() -> None:
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )
    allowed_prefixes = (
        f"?? {INSTALLER_NAME}",
        "?? payload/",
    )
    unexpected = [
        line
        for line in result.stdout.splitlines()
        if line.strip()
        and not any(line.strip().startswith(prefix) for prefix in allowed_prefixes)
    ]
    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def patch_main() -> None:
    path = REPO / "lib/main.dart"
    text = path.read_text(encoding="utf-8")
    if "part 'live_duel_result.dart';" not in text:
        text = replace_once(
            text,
            "part 'live_duel_play_screen.dart';\n",
            "part 'live_duel_play_screen.dart';\n"
            "part 'live_duel_result.dart';\n",
            "main.dart sonuç partı",
        )
    path.write_text(text, encoding="utf-8")


def patch_profile_service() -> None:
    path = REPO / "lib/live_duel_league.dart"
    text = path.read_text(encoding="utf-8")
    marker = "class LiveDuelProfileService {"
    index = text.find(marker)
    if index < 0:
        raise RuntimeError("LiveDuelProfileService bulunamadı.")
    replacement = read_payload("snippets/profile_service.txt")
    path.write_text(text[:index] + replacement, encoding="utf-8")


def patch_live_duel_screen() -> None:
    path = REPO / "lib/live_duel_screen.dart"
    text = path.read_text(encoding="utf-8")
    start = text.find("Future<void> _startMatchmaking")
    end = text.find("@override", start)
    section = text[start:end]
    if "await _loadProfile();" not in section:
        navigation = """      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder:
              (context) => LiveDuelSearchingScreen(
                questionCount: _selectedQuestionCount,
              ),
        ),
      );
"""
        text = replace_once(
            text,
            navigation,
            navigation + "\n      await _loadProfile();\n",
            "Canlı düello profil yenileme",
        )
    path.write_text(text, encoding="utf-8")


def patch_play_screen() -> None:
    path = REPO / "lib/live_duel_play_screen.dart"
    text = path.read_text(encoding="utf-8")

    fields_old = """  LiveDuelPlayerProgress? _ownProgress;
  LiveDuelPlayerProgress? _opponentProgress;

  bool _loading = true;
  bool _submitting = false;
  int _questionIndex = 0;
  int? _selectedOptionIndex;
  bool? _selectedAnswerCorrect;
  String? _errorMessage;
"""
    fields_new = """  LiveDuelPlayerProgress? _ownProgress;
  LiveDuelPlayerProgress? _opponentProgress;
  LiveDuelOwnResultAward? _ownAward;

  bool _loading = true;
  bool _submitting = false;
  bool _finalizingResult = false;
  int _questionIndex = 0;
  int? _selectedOptionIndex;
  bool? _selectedAnswerCorrect;
  String? _errorMessage;
  String? _resultError;
"""
    text = replace_once(
        text,
        fields_old,
        fields_new,
        "Sonuç ekranı durum alanları",
    )

    text = replace_between(
        text,
        "  void _handleProgress(",
        "  bool get _ownFinished",
        read_payload("snippets/play_handle.txt"),
        "İlerleme ve sonuç işleme",
    )

    text = replace_once(
        text,
        "    final canLeave = _bothFinished || fatal;",
        "    final canLeave = _ownAward != null || fatal;",
        "Maçtan çıkış güvenliği",
    )

    text = replace_once(
        text,
        """        if (_bothFinished)
          _buildResultView(own, opponent)
        else if (_ownFinished)
""",
        """        if (_bothFinished)
          (_ownAward != null
              ? _buildResultView(_ownAward!)
              : _buildFinalizingView())
        else if (_ownFinished)
""",
        "Resmi sonuç görünümü",
    )

    text = replace_between(
        text,
        "  Widget _buildResultView(",
        "\n}\n\nclass _LiveDuelScoreCard",
        read_payload("snippets/play_result_methods.txt"),
        "Sonuç kartı",
    )

    path.write_text(text, encoding="utf-8")


def patch_account_delete() -> None:
    path = REPO / "lib/account_cloud.dart"
    text = path.read_text(encoding="utf-8")
    old = """      await _firestore!
          .collection('users')
          .doc(user.uid)
          .delete();
"""
    new = """      await _deleteLiveDuelResultClaims(user.uid);

      await _firestore!
          .collection('users')
          .doc(user.uid)
          .delete();
"""
    text = replace_once(text, old, new, "Hesap silme sonuç temizliği")

    helper = """  Future<void> _deleteLiveDuelResultClaims(
    String uid,
  ) async {
    while (true) {
      final snapshot = await _firestore!
          .collection('users')
          .doc(uid)
          .collection('live_duel_results')
          .limit(100)
          .get();

      if (snapshot.docs.isEmpty) return;

      final batch = _firestore!.batch();
      for (final document in snapshot.docs) {
        batch.delete(document.reference);
      }
      await batch.commit();
    }
  }

"""
    marker = "  String _deletionFriendlyError(Object error) {"
    if "Future<void> _deleteLiveDuelResultClaims(" not in text:
        text = replace_once(
            text,
            marker,
            helper + marker,
            "Hesap silme yardımcı metodu",
        )

    sync_assignment = "      _syncTimer = Timer.periodic(\n"
    sync_guard = "      _syncTimer?.cancel();\n\n"
    if sync_guard not in text:
        text = replace_once(
            text,
            sync_assignment,
            sync_guard + sync_assignment,
            "Hesap eşitleme zamanlayıcısı kullanımı",
        )

    path.write_text(text, encoding="utf-8")


def patch_versions() -> None:
    replacements = [
        (
            "pubspec.yaml",
            "version: 1.54.0+75",
            "version: 1.55.0+76",
            "pubspec sürümü",
        ),
        (
            "lib/app_build_info.dart",
            "static const String versionName = '1.54.0';",
            "static const String versionName = '1.55.0';",
            "uygulama sürümü",
        ),
        (
            "lib/app_build_info.dart",
            "static const int buildNumber = 75;",
            "static const int buildNumber = 76;",
            "uygulama yapı numarası",
        ),
        (
            "tools/rc1_quality_gate.py",
            'EXPECTED_VERSION = "1.54.0+75"',
            'EXPECTED_VERSION = "1.55.0+76"',
            "kalite kapısı sürümü",
        ),
        (
            ".github/workflows/android-apk.yml",
            'echo "- Sürüm: 1.54.0+75"',
            'echo "- Sürüm: 1.55.0+76"',
            "iş akışı sürümü",
        ),
    ]
    for relative, old, new, label in replacements:
        path = REPO / relative
        text = path.read_text(encoding="utf-8")
        path.write_text(
            replace_once(text, old, new, label),
            encoding="utf-8",
        )


def copy_payload_files() -> None:
    files = {
        "lib/live_duel_result.dart": "lib/live_duel_result.dart",
        "test/live_duel_result_test.dart": "test/live_duel_result_test.dart",
        "firestore.rules": "firestore.rules",
        "BILGI_ROTASI_DURUM.md": "BILGI_ROTASI_DURUM.md",
    }
    for target, source in files.items():
        write_repo(target, read_payload(source))


def apply_package() -> None:
    copy_payload_files()
    patch_main()
    patch_profile_service()
    patch_live_duel_screen()
    patch_play_screen()
    patch_account_delete()
    patch_versions()


def run_format() -> None:
    run([
        "/workspaces/flutter/bin/dart",
        "format",
        "lib/main.dart",
        "lib/live_duel_league.dart",
        "lib/live_duel_screen.dart",
        "lib/live_duel_play_screen.dart",
        "lib/live_duel_result.dart",
        "lib/account_cloud.dart",
        "lib/app_build_info.dart",
        "test/live_duel_result_test.dart",
    ])


def run_analysis() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)
    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/live_duel_league.dart",
        "lib/live_duel_screen.dart",
        "lib/live_duel_play_screen.dart",
        "lib/live_duel_result.dart",
        "lib/account_cloud.dart",
        "lib/app_build_info.dart",
        "test/live_duel_result_test.dart",
    ]
    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )
    lines = (result.stdout + result.stderr).splitlines()
    blocking = [
        line
        for line in lines
        if line.startswith("ERROR|") or line.startswith("WARNING|")
    ]
    info_count = sum(line.startswith("INFO|") for line in lines)
    print(f"Analiz: {len(blocking)} hata/uyarı, {info_count} bilgi notu.")
    if blocking:
        print("\n".join(blocking[:20]))
        raise RuntimeError("Dart analizi hata veya uyarı verdi.")


def run_tests() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)
    tests = [
        "test/live_duel_result_test.dart",
        "test/live_duel_league_test.dart",
        "test/live_duel_progress_test.dart",
        "test/live_duel_play_screen_test.dart",
        "test/live_duel_screen_test.dart",
    ]
    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]
        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print("İlk deneme geçmedi; önbellek temizlenip tekrar deneniyor.")
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])
        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")


def finish_commit() -> None:
    print("\n4/5 RC2 kalite kapısı çalışıyor...", flush=True)
    run(["python3", "tools/rc1_quality_gate.py"])
    run(["git", "diff", "--check"])

    archive = REPO / ARCHIVE_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ARCHIVE_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
        if tracked:
            run(["git", "rm", "-f", ARCHIVE_NAME])
        else:
            archive.unlink()

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()
    if PAYLOAD.exists():
        shutil.rmtree(PAYLOAD)

    print("\n5/5 Commit ve push yapılıyor...", flush=True)
    run(["git", "add", "-A"])
    staged = subprocess.run(
        ["git", "diff", "--cached", "--quiet"],
        cwd=REPO,
        check=False,
    )
    if staged.returncode == 0:
        raise RuntimeError("Kaydedilecek değişiklik bulunamadı.")

    run(["git", "commit", "-m", "Canli duello sonucunu atomik isle"])
    run(["git", "push", "origin", "main"])

    print("\n" + "=" * 60)
    print("TAMAMLANDI")
    print("=" * 60)
    run(["git", "log", "-1", "--oneline"])


def rollback() -> None:
    print("\nDeğişiklikler güvenli biçimde geri alınıyor...", flush=True)
    subprocess.run(["git", "reset", "--hard", "HEAD"], cwd=REPO, check=False)
    for relative in [
        "lib/live_duel_result.dart",
        "test/live_duel_result_test.dart",
    ]:
        target = REPO / relative
        if target.exists():
            tracked = subprocess.run(
                ["git", "ls-files", "--error-unmatch", relative],
                cwd=REPO,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0
            if not tracked:
                target.unlink()


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ["post-checkout", "pre-push"]:
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()
        print("1/5 Kod paketi uygulanıyor...", flush=True)
        apply_package()
        run_format()
        run_analysis()
        run_tests()
        finish_commit()
        return 0
    except Exception as error:
        print(f"\nHATA: {error}")
        rollback()
        print("Kurulum geri alındı; paket tekrar çalıştırılabilir.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
