#!/usr/bin/env python3
from __future__ import annotations

import subprocess
from pathlib import Path


def main() -> int:
    repo_root = Path("/workspaces/BilgiRotasi")
    script_path = Path(__file__).with_name(
        "bilgi_rotasi_canli_duello_kurulum.sh"
    )

    if not repo_root.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    if not script_path.is_file():
        print("HATA: Kurulum betiği ZIP içinden çıkmadı.")
        return 1

    print("=" * 60)
    print("BİLGİ ROTASI - CANLI DÜELLO PAKETİ")
    print("=" * 60)

    completed = subprocess.run(
        ["bash", str(script_path)],
        cwd=repo_root,
        check=False,
    )
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
