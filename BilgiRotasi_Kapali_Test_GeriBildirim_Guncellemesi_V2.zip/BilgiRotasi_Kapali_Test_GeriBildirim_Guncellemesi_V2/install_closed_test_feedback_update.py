#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import json
import re
import shutil
import subprocess

BASE_BRANCH = "release/final-closed-test-aab-1.68.8"
WORK_BRANCH = "fix/closed-test-feedback-1.68.12"
QUESTIONS = Path("assets/questions.json")
PUBSPEC = Path("pubspec.yaml")
REPORT = Path("reports/closed_test_feedback_update_20260804.txt")
GUARD_SOURCE = Path("docs/question-feedback-apps-script-guard.gs")
README_SOURCE = Path("docs/closed-test-feedback-operations.md")

DIFFICULTY_UPDATES = json.loads('[{"id": "q57805", "question": "Pirkanmaa bölümü hangi ülkenin yönetim sistemine dâhildir?", "difficulty": "Zor", "reason": "Coğrafi/idari bölge bilgisi genel oyuncu için zor."}, {"id": "q56784", "question": "Geetanjali Shree hangi eserle 2022 ödül sezonunda öne çıktı?", "difficulty": "Zor", "reason": "İki farklı cihazdan Zor oyu aldı."}, {"id": "q56189", "question": "Güney Afrika’da ulusal birlik hükûmeti kurulması hangi yılda gerçekleşti?", "difficulty": "Zor", "reason": "Güncel ve ayrıntılı tarih bilgisi."}, {"id": "q56304", "question": "“The Promise” adlı eserin yazarı kimdir?", "difficulty": "Zor", "reason": "Niş edebiyat bilgisi."}, {"id": "q54045", "question": "Mass Effect serisinin insan ana kahramanının soyadı nedir?", "difficulty": "Orta", "reason": "Oyun serisine özgü karakter bilgisi."}, {"id": "q53752", "question": "Interstellar’da astronot Cooper’ın kızının adı nedir?", "difficulty": "Orta", "reason": "Film ayrıntısı."}, {"id": "q54807", "question": "Alp kayağının en hızlı disiplini hangisidir?", "difficulty": "Orta", "reason": "Spor dalına özgü bilgi."}, {"id": "q56602", "question": "“Stray” oyununu hangi stüdyo geliştirdi?", "difficulty": "Orta", "reason": "Oyun stüdyosu bilgisi."}, {"id": "q55227", "question": "1066’daki Hastings Savaşı’nın galibi kimdi?", "difficulty": "Orta", "reason": "Genel kitle için Kolay değil."}]')
QUESTION_REWRITE = json.loads('{"id": "q57860", "old_question": "“Abbott Elementary” ilk olarak hangi platform veya kanalda yayımlandı?", "old_correct_answer": "ABC", "new_question": "Abbott Elementary dizisi ABD’de ilk olarak hangi televizyon kanalında yayımlandı?", "new_options": ["NBC", "CBS", "FOX", "ABC"], "new_answer_index": 3, "new_difficulty": "Kolay", "new_explanation": "Abbott Elementary, ABD’de ilk olarak ABC kanalında yayımlandı."}')


def fail(message: str) -> None:
    raise SystemExit(f"\n❌ {message}\n")


def run(command: list[str], *, check: bool = True, capture: bool = False):
    return subprocess.run(
        command,
        check=check,
        text=True,
        capture_output=capture,
    )


def git_clean() -> bool:
    return run(["git", "status", "--porcelain"], capture=True).stdout.strip() == ""


def find_question(items: list[dict], question_id: str) -> dict:
    matches = [item for item in items if str(item.get("id", "")) == question_id]
    if len(matches) != 1:
        fail(f"{question_id}: beklenen tek kayıt yerine {len(matches)} kayıt bulundu.")
    return matches[0]


def correct_answer(item: dict) -> str:
    options = item.get("options")
    index = item.get("answerIndex")
    if not isinstance(options, list) or len(options) != 4:
        fail(f"{item.get('id')}: dört seçenek bulunamadı.")
    if not isinstance(index, int) or index < 0 or index >= len(options):
        fail(f"{item.get('id')}: doğru cevap indeksi geçersiz.")
    return str(options[index])


def patch_central_version(
    old_name: str,
    old_code: int,
    new_name: str,
    new_code: int,
) -> list[Path]:
    changed: list[Path] = []
    for path in Path("lib").rglob("*.dart"):
        text = path.read_text(encoding="utf-8")
        if not any(
            token in text
            for token in (
                "AppBuildInfo",
                "versionName",
                "versionCode",
                "appVersion",
                "buildNumber",
            )
        ):
            continue

        updated = text.replace(f"'{old_name}'", f"'{new_name}'")
        updated = updated.replace(f'"{old_name}"', f'"{new_name}"')
        updated = re.sub(
            rf"(\bversionCode\s*=\s*){old_code}\b",
            rf"\g<1>{new_code}",
            updated,
        )
        updated = re.sub(
            rf"(\bbuildNumber\s*=\s*){old_code}\b",
            rf"\g<1>{new_code}",
            updated,
        )
        if updated != text:
            path.write_text(updated, encoding="utf-8")
            changed.append(path)
    return changed


for required in (QUESTIONS, PUBSPEC):
    if not required.exists():
        fail(
            f"{required} bulunamadı. Dosyayı BilgiRotasi deposunun ana klasöründe çalıştır."
        )

if not Path(".git").exists():
    fail("Bu klasör bir Git deposu değil.")

# Script çalışırken başka dala geçileceği için paket yardımcılarını önce belleğe al.
package_dir = Path(__file__).resolve().parent
guard_package = package_dir / "apps_script_feedback_guard.gs"
readme_package = package_dir / "README_KURULUM.txt"
if not guard_package.exists() or not readme_package.exists():
    fail("Paket yardımcı dosyaları bulunamadı; ZIP'i eksiksiz aç.")
guard_text = guard_package.read_text(encoding="utf-8")
readme_text = readme_package.read_text(encoding="utf-8")

if not git_clean():
    fail("Repoda commit edilmemiş değişiklik var. Önce commit et veya temizle.")

run(["git", "fetch", "origin"])

if run(
    ["git", "rev-parse", "--verify", f"origin/{BASE_BRANCH}"],
    check=False,
    capture=True,
).returncode != 0:
    fail(f"Uzak dal bulunamadı: origin/{BASE_BRANCH}")

if run(
    ["git", "show-ref", "--verify", f"refs/heads/{WORK_BRANCH}"],
    check=False,
).returncode == 0:
    fail(f"{WORK_BRANCH} dalı zaten var; güvenlik için devam edilmedi.")

run(["git", "switch", BASE_BRANCH])
run(["git", "pull", "--ff-only", "origin", BASE_BRANCH])
run(["git", "switch", "-c", WORK_BRANCH])

try:
    questions = json.loads(QUESTIONS.read_text(encoding="utf-8"))
except Exception as error:
    fail(f"questions.json okunamadı: {error}")

if not isinstance(questions, list):
    fail("assets/questions.json bir JSON listesi olmalı.")

ids = [str(item.get("id", "")) for item in questions if isinstance(item, dict)]
if len(ids) != len(set(ids)):
    fail("Soru bankasında yinelenen soru kimliği var.")

changes: list[str] = []
already: list[str] = []

for update in DIFFICULTY_UPDATES:
    item = find_question(questions, update["id"])
    current_question = str(item.get("question", ""))
    if current_question != update["question"]:
        fail(
            f"{update['id']} başka bir çalışma tarafından değiştirilmiş.\n"
            f"Beklenen: {update['question']}\n"
            f"Mevcut:   {current_question}"
        )

    if item.get("difficulty") == update["difficulty"]:
        already.append(f"{update['id']} zaten {update['difficulty']}")
    else:
        old = str(item.get("difficulty", ""))
        item["difficulty"] = update["difficulty"]
        changes.append(f"{update['id']}: {old} → {update['difficulty']}")

item = find_question(questions, QUESTION_REWRITE["id"])
target_matches = (
    str(item.get("question", "")) == QUESTION_REWRITE["new_question"]
    and item.get("options") == QUESTION_REWRITE["new_options"]
    and item.get("answerIndex") == QUESTION_REWRITE["new_answer_index"]
    and item.get("difficulty") == QUESTION_REWRITE["new_difficulty"]
    and item.get("explanation") == QUESTION_REWRITE["new_explanation"]
)
if target_matches:
    already.append(f"{QUESTION_REWRITE['id']} zaten yenilenmiş")
else:
    if str(item.get("question", "")) != QUESTION_REWRITE["old_question"]:
        fail(
            f"{QUESTION_REWRITE['id']} başka bir çalışma tarafından değiştirilmiş.\n"
            f"Mevcut: {item.get('question')}"
        )
    if correct_answer(item) != QUESTION_REWRITE["old_correct_answer"]:
        fail(f"{QUESTION_REWRITE['id']}: mevcut doğru cevap ABC değil.")

    item["question"] = QUESTION_REWRITE["new_question"]
    item["options"] = QUESTION_REWRITE["new_options"]
    item["answerIndex"] = QUESTION_REWRITE["new_answer_index"]
    item["difficulty"] = QUESTION_REWRITE["new_difficulty"]
    item["explanation"] = QUESTION_REWRITE["new_explanation"]
    changes.append(
        f"{QUESTION_REWRITE['id']}: soru ve şıklar yalnız TV kanallarından oluşturuldu"
    )

for question in questions:
    if not isinstance(question, dict):
        fail("Soru bankasında nesne olmayan kayıt var.")
    if not str(question.get("id", "")).strip():
        fail("Kimliği boş soru bulundu.")
    options = question.get("options")
    answer_index = question.get("answerIndex")
    if not isinstance(options, list) or len(options) != 4:
        fail(f"{question.get('id')}: dört seçenek şartı bozuldu.")
    if not isinstance(answer_index, int) or answer_index not in (0, 1, 2, 3):
        fail(f"{question.get('id')}: cevap indeksi bozuldu.")
    if question.get("difficulty") not in ("Kolay", "Orta", "Zor"):
        fail(f"{question.get('id')}: geçersiz zorluk.")

QUESTIONS.write_text(
    json.dumps(questions, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)

pubspec = PUBSPEC.read_text(encoding="utf-8")
version_match = re.search(
    r"^version:\s*(\d+)\.(\d+)\.(\d+)\+(\d+)\s*$",
    pubspec,
    flags=re.MULTILINE,
)
if not version_match:
    fail("pubspec.yaml sürüm satırı okunamadı.")

major, minor, patch, build = map(int, version_match.groups())
old_name = f"{major}.{minor}.{patch}"
new_name = f"{major}.{minor}.{patch + 1}"
new_code = build + 1
new_full = f"{new_name}+{new_code}"

pubspec = re.sub(
    r"^version:\s*.*$",
    f"version: {new_full}",
    pubspec,
    count=1,
    flags=re.MULTILINE,
)
PUBSPEC.write_text(pubspec, encoding="utf-8")

central_version_files = patch_central_version(
    old_name,
    build,
    new_name,
    new_code,
)

GUARD_SOURCE.parent.mkdir(parents=True, exist_ok=True)
GUARD_SOURCE.write_text(guard_text, encoding="utf-8")
README_SOURCE.write_text(readme_text, encoding="utf-8")

REPORT.parent.mkdir(parents=True, exist_ok=True)
report_lines = [
    "BİLGİ ROTASI – KAPALI TEST GERİ BİLDİRİM GÜNCELLEMESİ",
    "=" * 78,
    "",
    f"Taban dal: {BASE_BRANCH}",
    f"Çalışma dalı: {WORK_BRANCH}",
    f"Yeni sürüm: {new_full}",
    "",
    "SORU DEĞİŞİKLİKLERİ",
    "-" * 78,
    *(changes or ["Yeni değişiklik yok."]),
    "",
    "ZATEN GÜNCEL OLANLAR",
    "-" * 78,
    *(already or ["Yok"]),
    "",
    "MERKEZİ SÜRÜM DOSYALARI",
    "-" * 78,
    *([str(path) for path in central_version_files] or ["Yalnız pubspec.yaml güncellendi."]),
    "",
    "NOT",
    "-" * 78,
    "Apps Script koruma kaynağı repoya eklendi fakat otomatik deploy edilmedi.",
]
REPORT.write_text("\n".join(report_lines) + "\n", encoding="utf-8")

json.loads(QUESTIONS.read_text(encoding="utf-8"))
run(["git", "diff", "--check"])

if shutil.which("dart") and central_version_files:
    run(["dart", "format", *[str(path) for path in central_version_files]])

if shutil.which("flutter"):
    run(["flutter", "analyze", "--no-fatal-warnings", "--no-fatal-infos"])
    if Path("test").exists():
        run(["flutter", "test", "--concurrency=1"])

paths_to_add = [
    QUESTIONS,
    PUBSPEC,
    REPORT,
    GUARD_SOURCE,
    README_SOURCE,
    *central_version_files,
]
run(["git", "add", *[str(path) for path in paths_to_add]])

if run(["git", "diff", "--cached", "--quiet"], check=False).returncode == 0:
    fail("Commit edilecek değişiklik bulunamadı.")

run(
    [
        "git",
        "commit",
        "-m",
        "Kapali test geri bildirimlerini guncelle",
    ]
)
run(["git", "push", "-u", "origin", WORK_BRANCH])

if shutil.which("gh"):
    pr = run(
        [
            "gh",
            "pr",
            "create",
            "--draft",
            "--base",
            BASE_BRANCH,
            "--head",
            WORK_BRANCH,
            "--title",
            f"fix: kapalı test geri bildirimleri {new_name}",
            "--body",
            (
                "Kapalı test geri bildirimlerinden 9 zorluk güncellemesi "
                "ve q57860 seçenek düzeltmesi. Apps Script koruma taslağı "
                "eklendi; backend deployment yapılmaz."
            ),
        ],
        check=False,
        capture=True,
    )
    if pr.returncode == 0:
        print(f"✅ Draft PR: {pr.stdout.strip()}")
    else:
        print("⚠️ Branch gönderildi; Draft PR otomatik açılamadı.")
else:
    print("ℹ️ GitHub CLI bulunamadı; Draft PR'ı GitHub ekranından aç.")

print("")
print("✅ Kapalı test geri bildirim paketi tamamlandı.")
print(f"✅ Çalışma dalı: {WORK_BRANCH}")
print(f"✅ Yeni sürüm: {new_full}")
print(f"✅ Değiştirilen hedef sayısı: {len(changes)}")
print("✅ Branch GitHub'a gönderildi.")
print("⚠️ Apps Script koruması otomatik deploy edilmedi.")
print(f"📄 Rapor: {REPORT}")
