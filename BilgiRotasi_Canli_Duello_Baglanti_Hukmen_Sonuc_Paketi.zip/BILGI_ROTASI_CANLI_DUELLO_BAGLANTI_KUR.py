#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
PAYLOAD = REPO / "payload"
ZIP_NAME = "BilgiRotasi_Canli_Duello_Baglanti_Hukmen_Sonuc_Paketi.zip"
INSTALLER_NAME = "BILGI_ROTASI_CANLI_DUELLO_BAGLANTI_KUR.py"


def run(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def read_payload(name: str) -> str:
    path = PAYLOAD / name
    if not path.is_file():
        raise RuntimeError(f"Payload eksik: {name}")
    return path.read_text(encoding="utf-8")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: beklenen metin {count} kez bulundu."
        )
    return text.replace(old, new, 1)


def replace_between(
    text: str,
    start: str,
    end: str,
    replacement: str,
    label: str,
) -> str:
    start_index = text.find(start)
    if start_index < 0:
        raise RuntimeError(f"{label}: başlangıç bulunamadı.")
    end_index = text.find(end, start_index)
    if end_index < 0:
        raise RuntimeError(f"{label}: bitiş bulunamadı.")
    return text[:start_index] + replacement + text[end_index:]


def ensure_clean_start() -> None:
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )
    allowed_names = {
        ZIP_NAME,
        INSTALLER_NAME,
        "payload/",
    }
    unexpected = []
    for line in result.stdout.splitlines():
        path = line[3:].strip()
        if not any(
            path == allowed.rstrip("/") or path.startswith(allowed)
            for allowed in allowed_names
        ):
            unexpected.append(line)

    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def patch_main() -> None:
    path = REPO / "lib/main.dart"
    text = path.read_text(encoding="utf-8")
    if "part 'live_duel_connection.dart';" not in text:
        text = replace_once(
            text,
            "part 'live_duel_result.dart';\n",
            "part 'live_duel_result.dart';\n"
            "part 'live_duel_connection.dart';\n",
            "main.dart bağlantı partı",
        )
    path.write_text(text, encoding="utf-8")


def patch_result() -> None:
    path = REPO / "lib/live_duel_result.dart"
    text = path.read_text(encoding="utf-8")

    if "enum LiveDuelCompletionType" not in text:
        text = replace_once(
            text,
            "class LiveDuelCompletedMatch {",
            "enum LiveDuelCompletionType { completed, forfeit }\n\n"
            "class LiveDuelCompletedMatch {",
            "Sonuç türü enumu",
        )

    old_constructor = """    required this.draw,
    required this.winnerUid,
    this.completedAt,
  });
"""
    new_constructor = """    required this.draw,
    required this.winnerUid,
    this.completionType = LiveDuelCompletionType.completed,
    this.forfeitLoserUid,
    this.completedAt,
  });
"""
    text = replace_once(
        text,
        old_constructor,
        new_constructor,
        "Tamamlanan maç kurucusu",
    )

    old_fields = """  final bool draw;
  final String? winnerUid;
  final DateTime? completedAt;
"""
    new_fields = """  final bool draw;
  final String? winnerUid;
  final LiveDuelCompletionType completionType;
  final String? forfeitLoserUid;
  final DateTime? completedAt;

  bool get forfeited =>
      completionType == LiveDuelCompletionType.forfeit;
"""
    text = replace_once(
        text,
        old_fields,
        new_fields,
        "Tamamlanan maç alanları",
    )

    old_validation = """    final expectedWinner = LiveDuelMatchResultResolver.winnerUid(
      playerUids: playerUids,
      scores: scores,
    );
    final rawWinnerUid = data['winnerUid'];
    final winnerUid = rawWinnerUid == null ? null : rawWinnerUid.toString();
    final draw = data['draw'] == true;

    if ((expectedWinner == null && (!draw || winnerUid != null)) ||
        (expectedWinner != null && (draw || winnerUid != expectedWinner))) {
      throw const LiveDuelResultException('Maç sonucu ile skorlar uyuşmuyor.');
    }

    final completedAt = data['completedAt'];
"""
    new_validation = """    final completionType =
        LiveDuelCompletionType.values.firstWhere(
      (item) =>
          item.name == data['completionType']?.toString(),
      orElse: () => LiveDuelCompletionType.completed,
    );
    final rawWinnerUid = data['winnerUid'];
    final winnerUid =
        rawWinnerUid == null ? null : rawWinnerUid.toString();
    final rawForfeitLoserUid = data['forfeitLoserUid'];
    final forfeitLoserUid = rawForfeitLoserUid == null
        ? null
        : rawForfeitLoserUid.toString();
    final draw = data['draw'] == true;

    if (completionType ==
        LiveDuelCompletionType.forfeit) {
      if (draw ||
          forfeitLoserUid == null ||
          !playerUids.contains(forfeitLoserUid) ||
          winnerUid == null ||
          !playerUids.contains(winnerUid) ||
          winnerUid == forfeitLoserUid) {
        throw const LiveDuelResultException(
          'Hükmen maç sonucu geçersiz.',
        );
      }
    } else {
      final expectedWinner =
          LiveDuelMatchResultResolver.winnerUid(
        playerUids: playerUids,
        scores: scores,
      );

      if ((expectedWinner == null &&
              (!draw || winnerUid != null)) ||
          (expectedWinner != null &&
              (draw || winnerUid != expectedWinner))) {
        throw const LiveDuelResultException(
          'Maç sonucu ile skorlar uyuşmuyor.',
        );
      }
    }

    final completedAt = data['completedAt'];
"""
    text = replace_once(
        text,
        old_validation,
        new_validation,
        "Sonuç doğrulaması",
    )

    old_return = """      draw: draw,
      winnerUid: winnerUid,
      completedAt: completedAt is Timestamp ? completedAt.toDate() : null,
"""
    new_return = """      draw: draw,
      winnerUid: winnerUid,
      completionType: completionType,
      forfeitLoserUid: forfeitLoserUid,
      completedAt:
          completedAt is Timestamp ? completedAt.toDate() : null,
"""
    text = replace_once(
        text,
        old_return,
        new_return,
        "Sonuç factory dönüşü",
    )

    text = replace_once(
        text,
        "'resultVersion': 1,",
        "'resultVersion': 2,\n"
        "        'completionType': "
        "LiveDuelCompletionType.completed.name,\n"
        "        'forfeitLoserUid': null,",
        "Normal sonuç sürümü",
    )

    old_finalize_return = """        draw: winnerUid == null,
        winnerUid: winnerUid,
        completedAt: completedAt,
"""
    new_finalize_return = """        draw: winnerUid == null,
        winnerUid: winnerUid,
        completionType:
            LiveDuelCompletionType.completed,
        forfeitLoserUid: null,
        completedAt: completedAt,
"""
    text = replace_once(
        text,
        old_finalize_return,
        new_finalize_return,
        "Normal sonuç dönüşü",
    )

    path.write_text(text, encoding="utf-8")


def patch_screens() -> None:
    screen_path = REPO / "lib/live_duel_screen.dart"
    screen = screen_path.read_text(encoding="utf-8")
    screen = replace_between(
        screen,
        "class _LiveDuelScreenState",
        "class LiveDuelSearchingScreen",
        read_payload("live_duel_screen_state.txt"),
        "Canlı düello ana ekranı",
    )
    screen_path.write_text(screen, encoding="utf-8")

    play_path = REPO / "lib/live_duel_play_screen.dart"
    play = play_path.read_text(encoding="utf-8")
    play = replace_between(
        play,
        "class _LiveDuelPlayScreenState",
        "class _LiveDuelScoreCard",
        read_payload("live_duel_play_state.txt"),
        "Canlı düello oyun ekranı",
    )
    play_path.write_text(play, encoding="utf-8")


def patch_versions() -> None:
    pubspec = REPO / "pubspec.yaml"
    text = pubspec.read_text(encoding="utf-8")
    text = replace_once(
        text,
        "version: 1.55.0+76",
        "version: 1.56.0+77",
        "pubspec sürümü",
    )
    pubspec.write_text(text, encoding="utf-8")

    build = REPO / "lib/app_build_info.dart"
    text = build.read_text(encoding="utf-8")
    text = replace_once(
        text,
        "static const String versionName = '1.55.0';",
        "static const String versionName = '1.56.0';",
        "uygulama sürümü",
    )
    text = replace_once(
        text,
        "static const int buildNumber = 76;",
        "static const int buildNumber = 77;",
        "uygulama yapı numarası",
    )
    build.write_text(text, encoding="utf-8")

    gate = REPO / "tools/rc1_quality_gate.py"
    text = gate.read_text(encoding="utf-8")
    text = replace_once(
        text,
        'EXPECTED_VERSION = "1.55.0+76"',
        'EXPECTED_VERSION = "1.56.0+77"',
        "kalite kapısı sürümü",
    )
    gate.write_text(text, encoding="utf-8")

    workflow = REPO / ".github/workflows/android-apk.yml"
    text = workflow.read_text(encoding="utf-8")
    text = replace_once(
        text,
        'echo "- Sürüm: 1.55.0+76"',
        'echo "- Sürüm: 1.56.0+77"',
        "GitHub Actions sürümü",
    )
    workflow.write_text(text, encoding="utf-8")


def install_payload() -> None:
    shutil.copy2(
        PAYLOAD / "live_duel_connection.dart",
        REPO / "lib/live_duel_connection.dart",
    )
    shutil.copy2(
        PAYLOAD / "live_duel_connection_test.dart",
        REPO / "test/live_duel_connection_test.dart",
    )
    shutil.copy2(
        PAYLOAD / "firestore.rules",
        REPO / "firestore.rules",
    )
    shutil.copy2(
        PAYLOAD / "BILGI_ROTASI_DURUM.md",
        REPO / "BILGI_ROTASI_DURUM.md",
    )


def analyze() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)
    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/live_duel_connection.dart",
        "lib/live_duel_result.dart",
        "lib/live_duel_screen.dart",
        "lib/live_duel_play_screen.dart",
        "lib/live_duel_progress.dart",
        "lib/live_duel_league.dart",
        "lib/app_build_info.dart",
        "test/live_duel_connection_test.dart",
    ]
    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )
    output = (result.stdout + result.stderr).splitlines()
    blocking = [
        line
        for line in output
        if line.startswith("ERROR|")
        or line.startswith("WARNING|")
    ]
    info_count = sum(
        line.startswith("INFO|") for line in output
    )
    print(
        f"Analiz: {len(blocking)} hata/uyarı, "
        f"{info_count} bilgi notu."
    )
    if blocking:
        print("\n".join(blocking[:20]))
        raise RuntimeError(
            "Dart analizi hata veya uyarı verdi."
        )


def test_all() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)
    tests = [
        "test/live_duel_connection_test.dart",
        "test/live_duel_result_test.dart",
        "test/live_duel_play_screen_test.dart",
        "test/live_duel_screen_test.dart",
        "test/live_duel_progress_test.dart",
        "test/live_duel_league_test.dart",
        "test/rc1_quality_gate_test.dart",
    ]

    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]
        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print(
            "Test ilk denemede geçmedi; "
            "önbellek temizlenip bir kez daha deneniyor."
        )
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])
        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")


def cleanup_package_files() -> None:
    shutil.rmtree(PAYLOAD, ignore_errors=True)

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ZIP_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
        if tracked:
            run(["git", "rm", "-f", ZIP_NAME])
        else:
            archive.unlink()


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()
        print("1/5 Bağlantı ve hükmen sonuç paketi uygulanıyor...")
        install_payload()
        patch_main()
        patch_result()
        patch_screens()
        patch_versions()

        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "lib/main.dart",
            "lib/live_duel_connection.dart",
            "lib/live_duel_result.dart",
            "lib/live_duel_screen.dart",
            "lib/live_duel_play_screen.dart",
            "lib/app_build_info.dart",
            "test/live_duel_connection_test.dart",
        ])

        analyze()
        test_all()

        print("\n4/5 RC2 kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        cleanup_package_files()

        print("\n5/5 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])

        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError(
                "Kaydedilecek değişiklik bulunamadı."
            )

        run([
            "git",
            "commit",
            "-m",
            "Canli duello baglanti ve hukmen sonucu ekle",
        ])
        run(["git", "push", "origin", "main"])

        print("\n" + "=" * 60)
        print("TAMAMLANDI")
        print("=" * 60)
        run(["git", "log", "-1", "--oneline"])
        print(
            "NOT: Firestore kuralları dosyada güncellendi. "
            "Gerçek cihaz testinden önce Firebase'e dağıtılmalı."
        )
        return 0

    except Exception as error:
        print(f"\nHATA: {error}")
        print(
            "Değişiklikler güvenli biçimde geri alınıyor..."
        )
        subprocess.run(
            ["git", "reset", "--hard", "HEAD"],
            cwd=REPO,
            check=False,
        )
        for path in [
            REPO / "lib/live_duel_connection.dart",
            REPO / "test/live_duel_connection_test.dart",
        ]:
            if path.exists():
                tracked = subprocess.run(
                    [
                        "git",
                        "ls-files",
                        "--error-unmatch",
                        str(path.relative_to(REPO)),
                    ],
                    cwd=REPO,
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                ).returncode == 0
                if not tracked:
                    path.unlink()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
