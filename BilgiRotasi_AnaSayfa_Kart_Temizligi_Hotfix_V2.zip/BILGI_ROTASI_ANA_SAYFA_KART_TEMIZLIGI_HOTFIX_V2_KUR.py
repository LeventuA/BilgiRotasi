#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

REPO = Path('/workspaces/BilgiRotasi')
ZIP_NAME = 'BilgiRotasi_AnaSayfa_Kart_Temizligi_Hotfix_V2.zip'
INSTALLER_NAME = 'BILGI_ROTASI_ANA_SAYFA_KART_TEMIZLIGI_HOTFIX_V2_KUR.py'
OLD_INSTALLER_NAME = 'BILGI_ROTASI_ANA_SAYFA_KART_TEMIZLIGI_HOTFIX_KUR.py'
OLDER_INSTALLER_NAME = 'BILGI_ROTASI_ANA_SAYFA_KART_TEMIZLIGI_KUR.py'
OLD_HOTFIX_ZIP_NAME = 'BilgiRotasi_AnaSayfa_Kart_Temizligi_Hotfix.zip'
OLD_ZIP_NAME = 'BilgiRotasi_AnaSayfa_Kart_Temizligi_Paketi.zip'

OLD_VERSION = '1.58.0+79'
NEW_VERSION = '1.59.0+80'
OLD_VERSION_NAME = '1.58.0'
NEW_VERSION_NAME = '1.59.0'
OLD_BUILD = '79'
NEW_BUILD = '80'
OLD_ARTIFACT_VERSION = '1.58.0-79'
NEW_ARTIFACT_VERSION = '1.59.0-80'

HOME_TEST = r'''import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Ana sayfa üst kart düzeni', () {
    late String source;
    late String homeBuild;

    setUpAll(() {
      source = File('lib/main.dart').readAsStringSync();

      final homeStart = source.indexOf(
        'class _HomeScreenState extends State<HomeScreen>',
      );
      final buildStart = source.indexOf(
        'Widget build(BuildContext context)',
        homeStart,
      );
      final buildEnd = source.indexOf(
        'Widget _buildHeroHeader()',
        buildStart,
      );

      expect(homeStart, greaterThanOrEqualTo(0));
      expect(buildStart, greaterThanOrEqualTo(0));
      expect(buildEnd, greaterThan(buildStart));

      homeBuild = source.substring(buildStart, buildEnd);
    });

    test('Oyuna Başla kartı ana sayfada bulunmaz', () {
      expect(homeBuild, isNot(contains('_buildNewGameCard()')));
      expect(source, isNot(contains('Widget _buildNewGameCard()')));
      expect(homeBuild, isNot(contains('Standart Tahta Oyununu Başlat')));
    });

    test('Günlük görev kartı ana sayfada bulunmaz', () {
      expect(
        homeBuild,
        isNot(contains('DailyChallengeHomeCard')),
      );
      expect(
        homeBuild,
        isNot(contains('AccountCloudService.dailyVisible')),
      );
    });

    test('yalnızca gerçek kayıtlı oyun kartı korunur', () {
      expect(homeBuild, contains('FutureBuilder<SavedGame?>'));
      expect(homeBuild, contains('savedGame == null'));
      expect(
        homeBuild,
        contains('return _buildSavedGameCard(savedGame);'),
      );
      expect(
        homeBuild,
        contains('return const SizedBox.shrink();'),
      );
    });
  });
}
'''

STATUS_MD = r'''# Bilgi Rotası – Proje Durumu

## Son Sürüm

**1.59.0+80**

## Son Tamamlanan İş

Ana sayfa üst bölümündeki gereksiz kartlar kaldırıldı.

- **Oyuna Başla** kartı ana sayfadan kaldırıldı.
- **Günlük Görev** kartı ana sayfadan kaldırıldı.
- Kayıt kontrolü sırasında yükleme kartı gösterilmiyor.
- Ana sayfada yalnızca gerçek bir kayıtlı oyun varsa
  **Devam Eden Oyun** kartı gösteriliyor.
- Kayıt yoksa hesap kartından sonra doğrudan **Bölümler** alanı geliyor.
- Kayıtlı oyundaki **Oyuna Devam Et** ve **Kayıtlı Oyunu Sil**
  işlemleri korunuyor.
- Ana sayfa düzenini koruyan otomatik kaynak sözleşmesi testi eklendi.
- Canlı Düello karışık kategori ve sabit zorluk dağılımı korunuyor.
- Firestore kuralları `bilgi-rotasi-f255d` projesinde yayında.

## Sıradaki İş

- Yeni 1.59.0+80 APK ile ana sayfayı doğrulama
- Kayıtsız durumda üst kartların görünmediğini kontrol etme
- Kayıt oluşturup yalnızca Devam Eden Oyun kartının çıktığını kontrol etme
- Canlı Düello iki cihaz testlerine devam etme
- 20 ve 30 soruluk maçları doğrulama
- Hükmen sonuç ve yarım maça dönüş senaryolarını kontrol etme

## Dokunulmaması Gerekenler

- `assets/questions.json` içindeki doğrulanmış soru bankası
- Mevcut Google giriş ve hesap silme sistemi
- Çalışan bulut kayıt sistemi
- Çalışan normal oyun modları
- Firestore koleksiyon adları geçiş planı olmadan değiştirilmemeli

## Bilinen Durumlar

- Toplam soru sayısı: **6710**
- Gerçek iki telefonla uçtan uca test devam ediyor.
- Ana sayfa kayıt kartı doğrudan `GameSaveService.load()` sonucuna bağlıdır.
'''


def run(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    print('$', ' '.join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: beklenen metin {count} kez bulundu.')
    return text.replace(old, new, 1)


def remove_known_temp_files() -> None:
    for name in (
        'firebase-debug.log',
        'FIREBASE_GIRIS_LINKI.txt',
        '000_FIREBASE_GIRIS_LINKI.txt',
        OLD_INSTALLER_NAME,
        OLDER_INSTALLER_NAME,
    ):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start() -> None:
    remove_known_temp_files()

    result = subprocess.run(
        ['git', 'status', '--porcelain'],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )

    allowed = {f'?? {INSTALLER_NAME}'}
    unexpected = [
        line
        for line in result.stdout.splitlines()
        if line.strip() and line.strip() not in allowed
    ]

    if unexpected:
        print('HATA: Çalışma alanında beklenmeyen değişiklik var:')
        print('\n'.join(unexpected))
        raise RuntimeError('Önce çalışma alanı temizlenmeli.')


def patch_home_screen() -> None:
    path = REPO / 'lib/main.dart'
    text = path.read_text(encoding='utf-8')

    old_build = '''                const AccountSummaryCard(),
                const SizedBox(height: 12),
                _buildNewGameCard(),
                const SizedBox(height: 10),
                FutureBuilder<SavedGame?>(
                  future: _savedGameFuture,
                  builder: (context, snapshot) {
                    final savedGame = snapshot.data;

                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return _buildLoadingCard();
                    }

                    if (savedGame == null) {
                      return const SizedBox.shrink();
                    }

                    return _buildSavedGameCard(savedGame);
                  },
                ),
                if (AccountCloudService.dailyVisible) ...[
                  const SizedBox(height: 12),
                  DailyChallengeHomeCard(questionBank: widget.questionBank),
                ],
                const SizedBox(height: 12),
'''

    new_build = '''                const AccountSummaryCard(),
                const SizedBox(height: 12),
                FutureBuilder<SavedGame?>(
                  future: _savedGameFuture,
                  builder: (context, snapshot) {
                    final savedGame = snapshot.data;

                    if (snapshot.connectionState == ConnectionState.waiting ||
                        savedGame == null) {
                      return const SizedBox.shrink();
                    }

                    return _buildSavedGameCard(savedGame);
                  },
                ),
                const SizedBox(height: 12),
'''

    text = replace_once(
        text,
        old_build,
        new_build,
        'Ana sayfa üst kart listesi',
    )

    pattern = re.compile(
        r'\n  Widget _buildLoadingCard\(\) \{.*?'
        r'\n  Widget _buildFeatureStrip\(\) \{',
        re.DOTALL,
    )

    text, count = pattern.subn(
        '\n  Widget _buildFeatureStrip() {',
        text,
        count=1,
    )

    if count != 1:
        raise RuntimeError(
            'Oyuna Başla ve yükleme kartı metotları bulunamadı.'
        )

    required = (
        'FutureBuilder<SavedGame?>',
        'return _buildSavedGameCard(savedGame);',
        'Widget _buildSavedGameCard(SavedGame savedGame)',
    )
    missing = [item for item in required if item not in text]
    if missing:
        raise RuntimeError(
            'Kayıtlı oyun kartı yanlışlıkla kaldırıldı: '
            + ', '.join(missing)
        )

    forbidden = (
        '_buildNewGameCard(),',
        'Widget _buildNewGameCard()',
        'Widget _buildLoadingCard()',
    )
    leftovers = [item for item in forbidden if item in text]
    if leftovers:
        raise RuntimeError(
            'Kaldırılması gereken kart kodu kaldı: '
            + ', '.join(leftovers)
        )

    path.write_text(text, encoding='utf-8')


def write_new_files() -> None:
    (REPO / 'test/home_screen_card_visibility_test.dart').write_text(
        HOME_TEST,
        encoding='utf-8',
    )
    (REPO / 'BILGI_ROTASI_DURUM.md').write_text(
        STATUS_MD,
        encoding='utf-8',
    )


def patch_versions() -> None:
    pubspec = REPO / 'pubspec.yaml'
    text = pubspec.read_text(encoding='utf-8')
    text = replace_once(
        text,
        f'version: {OLD_VERSION}',
        f'version: {NEW_VERSION}',
        'pubspec sürümü',
    )
    pubspec.write_text(text, encoding='utf-8')

    build_info = REPO / 'lib/app_build_info.dart'
    text = build_info.read_text(encoding='utf-8')
    text = replace_once(
        text,
        f"static const String versionName = '{OLD_VERSION_NAME}';",
        f"static const String versionName = '{NEW_VERSION_NAME}';",
        'uygulama sürümü',
    )
    text = replace_once(
        text,
        f'static const int buildNumber = {OLD_BUILD};',
        f'static const int buildNumber = {NEW_BUILD};',
        'uygulama yapı numarası',
    )
    build_info.write_text(text, encoding='utf-8')

    gate = REPO / 'tools/rc1_quality_gate.py'
    text = gate.read_text(encoding='utf-8')
    text = replace_once(
        text,
        f'EXPECTED_VERSION = "{OLD_VERSION}"',
        f'EXPECTED_VERSION = "{NEW_VERSION}"',
        'kalite kapısı sürümü',
    )
    gate.write_text(text, encoding='utf-8')

    workflow = REPO / '.github/workflows/android-apk.yml'
    text = workflow.read_text(encoding='utf-8')

    if OLD_VERSION not in text:
        raise RuntimeError('GitHub Actions güncel sürüm satırı bulunamadı.')
    text = text.replace(OLD_VERSION, NEW_VERSION)

    if OLD_ARTIFACT_VERSION not in text:
        raise RuntimeError('GitHub Actions artifact sürümü bulunamadı.')
    text = text.replace(
        OLD_ARTIFACT_VERSION,
        NEW_ARTIFACT_VERSION,
    )

    workflow.write_text(text, encoding='utf-8')


def analyze() -> None:
    print('\n2/5 Dart analizi çalışıyor...', flush=True)

    command = [
        '/workspaces/flutter/bin/dart',
        'analyze',
        '--format',
        'machine',
        'lib/main.dart',
        'lib/app_build_info.dart',
        'test/home_screen_card_visibility_test.dart',
    ]

    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )

    output = (result.stdout + result.stderr).splitlines()
    errors = [line for line in output if line.startswith('ERROR|')]
    warnings = [line for line in output if line.startswith('WARNING|')]
    infos = [line for line in output if line.startswith('INFO|')]

    print(
        f'Analiz: {len(errors)} hata, '
        f'{len(warnings)} uyarı, {len(infos)} bilgi notu.'
    )

    if errors:
        print('\n'.join(errors[:40]))
        raise RuntimeError('Dart analizi hata verdi.')


def run_tests() -> None:
    print('\n3/5 Testler tek tek çalışıyor...', flush=True)

    tests = [
        'test/home_screen_card_visibility_test.dart',
        'test/live_duel_questions_test.dart',
        'test/live_duel_menu_entry_test.dart',
        'test/rc1_quality_gate_test.dart',
    ]

    for test in tests:
        print(f'\nTEST: {test}', flush=True)
        command = [
            '/workspaces/flutter/bin/flutter',
            'test',
            test,
            '--concurrency=1',
            '--reporter',
            'expanded',
        ]

        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print(
            'Test ilk denemede geçmedi; '
            'önbellek temizlenip bir kez daha deneniyor.'
        )
        shutil.rmtree(REPO / '.dart_tool', ignore_errors=True)
        shutil.rmtree(REPO / 'build', ignore_errors=True)
        run(['/workspaces/flutter/bin/flutter', 'pub', 'get'])

        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f'Test başarısız: {test}')


def remove_package_file(name: str) -> None:
    path = REPO / name
    if not path.exists():
        return

    tracked = subprocess.run(
        ['git', 'ls-files', '--error-unmatch', name],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0

    if tracked:
        run(['git', 'rm', '-f', name])
    else:
        path.unlink()


def cleanup_package_files() -> None:
    remove_known_temp_files()

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    remove_package_file(ZIP_NAME)
    remove_package_file(OLD_HOTFIX_ZIP_NAME)
    remove_package_file(OLD_ZIP_NAME)


def rollback() -> None:
    subprocess.run(
        ['git', 'reset', '--hard', 'HEAD'],
        cwd=REPO,
        check=False,
    )

    test_path = REPO / 'test/home_screen_card_visibility_test.dart'
    if test_path.exists():
        tracked = subprocess.run(
            [
                'git',
                'ls-files',
                '--error-unmatch',
                'test/home_screen_card_visibility_test.dart',
            ],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
        if not tracked:
            test_path.unlink()


def main() -> int:
    if not REPO.is_dir():
        print('HATA: /workspaces/BilgiRotasi bulunamadı.')
        return 1

    subprocess.run(
        ['git', 'config', '--unset', 'core.hooksPath'],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ('post-checkout', 'pre-push'):
        (REPO / '.git/hooks' / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()

        print('1/5 Ana sayfa kart temizliği hotfix V2 uygulanıyor...')
        patch_home_screen()
        write_new_files()
        patch_versions()

        run([
            '/workspaces/flutter/bin/dart',
            'format',
            'lib/main.dart',
            'lib/app_build_info.dart',
            'test/home_screen_card_visibility_test.dart',
        ])

        analyze()
        run_tests()

        print('\n4/5 RC2 kalite kapısı çalışıyor...')
        run(['python3', 'tools/rc1_quality_gate.py'])
        run(['git', 'diff', '--check'])

        cleanup_package_files()

        print('\n5/5 Commit ve push yapılıyor...')
        run(['git', 'add', '-A'])

        staged = subprocess.run(
            ['git', 'diff', '--cached', '--quiet'],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError('Kaydedilecek değişiklik bulunamadı.')

        run([
            'git',
            'commit',
            '-m',
            'Ana sayfa ust kartlarini kaldir',
        ])
        run(['git', 'push', 'origin', 'main'])

        print('\n' + '=' * 60)
        print('TAMAMLANDI')
        print('=' * 60)
        run(['git', 'log', '-1', '--oneline'])
        print(
            'GitHub Actions yeni 1.59.0+80 APK ve AAB '
            'derlemesini otomatik başlatacak.'
        )
        return 0

    except Exception as error:
        print(f'\nHATA: {error}')
        print('Değişiklikler güvenli biçimde geri alınıyor...')
        rollback()
        print(
            f'Paket geri alındı; {INSTALLER_NAME} '
            'dosyasıyla tekrar denenebilir.'
        )
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
