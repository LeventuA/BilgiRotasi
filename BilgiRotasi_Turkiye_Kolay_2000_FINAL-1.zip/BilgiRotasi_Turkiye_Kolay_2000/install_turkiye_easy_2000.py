#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, unicodedata, shutil, tempfile, os
from pathlib import Path
from collections import defaultdict, Counter
from difflib import SequenceMatcher
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
PRIMARY=HERE/'turkiye_easy_2000_q59121_q61120.json'
RESERVES=HERE/'reserves_turkiye_easy_120_q61121_q61240.json'

def norm(s):
    s=unicodedata.normalize('NFKD',str(s).casefold())
    s=''.join(c for c in s if not unicodedata.combining(c))
    s=re.sub(r'[^a-z0-9çğıöşü]+',' ',s)
    return ' '.join(s.split()).replace('ı','i')

SIM_STOP={
 'hangi','hangisi','kimdir','nedir','olarak','bilinir','turk','turkiye','asagidaki','dogru','cevap',
 'sorusu','sorusunun','adli','eserin','eserinin','romaninin','siirinin','filminin','dizisinde','dizisinin',
 'ilimizdedir','ilimizle','ilinde','ilinin','sehrimizdedir','bolgesi','bolgenin','cografi','haritada','sinirlari',
 'icinde','alir','aramak','gerekir','yedi','yer','alan','bulunan','tarihinde','gerceklesen','gerceklesmistir',
 'takimi','takiminin','oyuncu','futbolcu','sporcu','sanatci','yazar','sair','yonetmeni','yonetmenlerinden',
 'karakteri','canlandirdi','oynadi','tarafindan','yazilmistir','seslendirilmistir','taninmis','tarihi','dogal'
}
def content_tokens(text):
    generic=('bolge','ilimiz','ilini','ilinde','icinde','icindedir','ozdesles','tanin','unlen','soru','cevap','hangis','kimd','nedir','yazil','seslendir','canlandir','gercekles','tarih','adli','eser','roman','film','dizi','turk','asagidaki','camii','cami','mimari','yonetmen','sair','yazar','karakter','rolu','isim','tablo','yoresel','lezzet','denince','akla','gelen','sarki','sanatci','grup','cekmistir','sinemaci','bulundugu','sinirlari','haritada','döküldüğü','dokuldugu')
    return {t for t in norm(text).split() if len(t)>=4 and t not in SIM_STOP and not any(st in t for st in generic)}

def similar_fact(q1,q2):
    n1=norm(q1); n2=norm(q2); t1=set(n1.split()); t2=set(n2.split())
    jac=len(t1&t2)/max(1,len(t1|t2)); ratio=SequenceMatcher(None,n1,n2).ratio()
    c1=content_tokens(q1); c2=content_tokens(q2); shared=c1&c2
    entity_overlap=(len(shared)>=2) or (bool(c1) and c1==c2)
    return entity_overlap and (jac>=0.50 or ratio>=0.80)

def schema(q):
    return (isinstance(q,dict) and set(q)=={'id','categoryIndex','question','options','answerIndex','difficulty','explanation'}
      and isinstance(q['id'],str) and q['id'] and q['categoryIndex'] in range(6)
      and isinstance(q['question'],str) and len(q['question'].strip())>=10
      and isinstance(q['options'],list) and len(q['options'])==4 and len({norm(x) for x in q['options']})==4
      and q['answerIndex'] in range(4) and q['difficulty']=='Kolay'
      and isinstance(q['explanation'],str) and len(q['explanation'].strip())>=12)

def is_conflict(q,ids,texts,by_answer):
    if q['id'] in ids: return 'id'
    nq=norm(q['question'])
    if nq in texts: return 'exact_question'
    ans=norm(q['options'][q['answerIndex']]); toks=set(nq.split())
    for old in by_answer.get((q['categoryIndex'],ans),[]):
        no=norm(old['question']); ot=set(no.split())
        if similar_fact(q['question'],old['question']): return 'near_question'
    return None

def index(items):
    ids={q['id'] for q in items}; texts={norm(q['question']) for q in items}; by=defaultdict(list)
    for q in items: by[(q['categoryIndex'],norm(q['options'][q['answerIndex']]))].append(q)
    return ids,texts,by

def add_index(q,ids,texts,by):
    ids.add(q['id']); texts.add(norm(q['question']))
    by[(q['categoryIndex'],norm(q['options'][q['answerIndex']]))].append(q)

def main():
    ap=argparse.ArgumentParser(description='Bilgi Rotası Türkiye özel 2.000 kolay soru kurucusu')
    ap.add_argument('--repo-root',default='.')
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--apply',action='store_true')
    ap.add_argument('--skip-conflicts',action='store_true')
    a=ap.parse_args()
    root=Path(a.repo_root).resolve(); target=root/'assets'/'questions.json'
    if not target.exists(): raise SystemExit(f'Bulunamadı: {target}')
    existing=json.loads(target.read_text(encoding='utf-8'))
    primary=json.loads(PRIMARY.read_text(encoding='utf-8')); reserves=json.loads(RESERVES.read_text(encoding='utf-8'))
    if not isinstance(existing,list): raise SystemExit('questions.json bir JSON listesi değil.')
    bad=[q.get('id','?') if isinstance(q,dict) else '?' for q in primary+reserves if not schema(q)]
    if bad: raise SystemExit(f'Paket şema hatası: {bad[:10]}')
    ids,texts,by=index(existing)
    near_existing=defaultdict(list,{k:list(v) for k,v in by.items()})
    accepted=[]; substitutions=[]; unresolved=[]; reasons=Counter(); reserve_used=set()
    reserve_by_cat=defaultdict(list)
    for r in reserves: reserve_by_cat[r['categoryIndex']].append(r)
    for q in primary:
        reason=is_conflict(q,ids,texts,near_existing)
        if not reason:
            accepted.append(q); add_index(q,ids,texts,by); continue
        reasons[reason]+=1
        replacement=None
        for r in reserve_by_cat[q['categoryIndex']]:
            if r['id'] in reserve_used: continue
            if not is_conflict(r,ids,texts,near_existing): replacement=r; break
        if replacement:
            reserve_used.add(replacement['id']); accepted.append(replacement); add_index(replacement,ids,texts,by)
            substitutions.append({'primary_id':q['id'],'reserve_id':replacement['id'],'reason':reason})
        else:
            unresolved.append({'id':q['id'],'reason':reason,'question':q['question']})
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    outdir=root/'quality_turkiye_easy_2000_install_output'; outdir.mkdir(exist_ok=True)
    report={
      'timestamp_utc':stamp,'existing_count':len(existing),'primary_count':len(primary),'reserve_count':len(reserves),
      'accepted_count':len(accepted),'substitution_count':len(substitutions),'unresolved_count':len(unresolved),
      'projected_total':len(existing)+len(accepted),'conflict_reasons':dict(reasons),
      'substitutions':substitutions,'unresolved':unresolved,'mode':'check' if a.check else 'apply'
    }
    rp=outdir/f'turkiye_easy_2000_install_report_{stamp}.json'
    rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'Mevcut soru       : {len(existing)}')
    print(f'Ana paket          : {len(primary)}')
    print(f'Yedek soru         : {len(reserves)}')
    print(f'Temiz kabul        : {len(accepted)}')
    print(f'Yedekle değişen    : {len(substitutions)}')
    print(f'Çözülemeyen        : {len(unresolved)}')
    print(f'Yeni olası toplam  : {len(existing)+len(accepted)}')
    print(f'Rapor               : {rp}')
    if a.check:
        print('Kontrol tamamlandı; questions.json değiştirilmedi.')
        return
    if unresolved and not a.skip_conflicts:
        print('Çözülemeyen çakışma bulundu; questions.json değiştirilmedi.')
        print('Temizleri eklemek için --skip-conflicts kullanın.')
        raise SystemExit(2)
    backup_dir=root/'.question_backups'; backup_dir.mkdir(exist_ok=True)
    backup=backup_dir/f'questions.json.{stamp}.before_turkiye_easy_2000.bak'
    shutil.copy2(target,backup)
    new_data=existing+accepted
    target.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='questions.',suffix='.tmp',dir=str(target.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(new_data,f,ensure_ascii=False,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,target)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    # Reload proof.
    reloaded=json.loads(target.read_text(encoding='utf-8'))
    if len(reloaded)!=len(new_data): raise SystemExit('Yazma sonrası sayı doğrulaması başarısız.')
    print(f'Başarıyla eklendi   : {len(accepted)}')
    print(f'Yeni toplam         : {len(reloaded)}')
    print(f'Tam yedek           : {backup}')

if __name__=='__main__': main()
