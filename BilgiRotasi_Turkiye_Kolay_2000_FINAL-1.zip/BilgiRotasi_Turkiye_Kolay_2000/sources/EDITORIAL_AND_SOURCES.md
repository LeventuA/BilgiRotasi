# Kaynak ve editoryal yaklaşım

Paket; Türkiye coğrafyası, Türk dizi/film/müzik kültürü, tarih, sanat-edebiyat, bilim-doğa ve spor alanlarındaki genel ve kalıcı bilgi birikiminden hazırlanmıştır.

Örneklemeli doğrulamada resmî kurum ve birincil kaynak türleri tercih edilir: Kültür ve Turizm Bakanlığı, Millî Eğitim Bakanlığı, TÜBİTAK, Türkiye Uzay Ajansı, federasyonlar, UEFA/FIBA/CEV ve eser/yapım künyeleri.

Bu dosya 2.000 maddenin her biri için bağımsız insan kaynak denetimi yapıldığı anlamına gelmez. Kullanıcı testinde şüpheli görülen maddeler ayrıca düzeltilmelidir.
