# Bilgi Rotası — Türkiye Özel 2.000 Kolay Soru

Bu paket yalnızca Türkiye odaklı, kolay seviyede 2.000 ana soru içerir.

- Ana ID aralığı: `q59121`–`q61120`
- Çakışma yedekleri: `q61121`–`q61240` (120 soru)
- Her soruda dört farklı şık ve kısa açıklama vardır.
- “Hangi şehri temsil eder?” gibi cevabı adında taşıyan takım-şehir soruları yasaktır.
- Önceki altı 1.000’lik aday paketle birebir ve güçlü yakın tekrar kontrolü yapılmıştır.
- Kurucu gerçek `assets/questions.json` üzerinde yeniden kontrol yapar ve gerekirse aynı kategoriden yedek kullanır.

## Kurulum

```bash
python3 BilgiRotasi_Turkiye_Kolay_2000/install_turkiye_easy_2000.py --repo-root . --check
python3 BilgiRotasi_Turkiye_Kolay_2000/install_turkiye_easy_2000.py --repo-root . --apply
```

Çözülemeyen çakışma kalırsa temiz soruları eklemek için son komuta `--skip-conflicts` eklenebilir.

## Doğruluk notu

Sorular model tarafından hazırlanmış; şema, tekrar, yakın tekrar, cevap sızıntısı ve dil kalıbı kontrollerinden geçirilmiştir. 2.000 sorunun tamamı bağımsız bir insan editör tarafından kaynak kaynak doğrulanmış değildir. Değişebilen güncel unvanlar yerine ağırlıkla tarihsel ve kalıcı bilgiler tercih edilmiştir.
