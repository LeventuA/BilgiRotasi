#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
ZIP_NAME = "BilgiRotasi_Canli_Duello_Karisik_Soru_Dagilimi_Paketi.zip"
INSTALLER_NAME = "BILGI_ROTASI_CANLI_DUELLO_KARISIK_SORU_KUR.py"

OLD_VERSION = "1.57.0+78"
NEW_VERSION = "1.58.0+79"
OLD_VERSION_NAME = "1.57.0"
NEW_VERSION_NAME = "1.58.0"
OLD_BUILD = "78"
NEW_BUILD = "79"
OLD_ARTIFACT_VERSION = "1.57.0-78"
NEW_ARTIFACT_VERSION = "1.58.0-79"

NEW_QUESTIONS = "part of 'main.dart';\n\nclass LiveDuelQuestionSetException implements Exception {\n  const LiveDuelQuestionSetException(this.message);\n\n  final String message;\n\n  @override\n  String toString() => message;\n}\n\nclass LiveDuelQuestionSet {\n  const LiveDuelQuestionSet({\n    required this.questionIds,\n    required this.questions,\n  });\n\n  final List<String> questionIds;\n  final List<QuizQuestion> questions;\n\n  int get length => questions.length;\n}\n\nclass LiveDuelQuestionSetService {\n  LiveDuelQuestionSetService._();\n\n  static const int currentVersion = 2;\n\n  static bool supportsQuestionSetVersion(Object? value) {\n    return (value as num?)?.toInt() == currentVersion;\n  }\n\n  static Map<String, int> difficultyTargetsForCount(\n    int questionCount,\n  ) {\n    return switch (questionCount) {\n      10 => const <String, int>{\n          'Kolay': 5,\n          'Orta': 3,\n          'Zor': 2,\n        },\n      20 => const <String, int>{\n          'Kolay': 10,\n          'Orta': 6,\n          'Zor': 4,\n        },\n      30 => const <String, int>{\n          'Kolay': 15,\n          'Orta': 9,\n          'Zor': 6,\n        },\n      _ => throw const LiveDuelQuestionSetException(\n          'Canlı düello soru sayısı geçersiz.',\n        ),\n    };\n  }\n\n  static Future<List<String>> createQuestionIds({\n    required int questionCount,\n    required int seed,\n  }) async {\n    final bank = await QuestionBank.load();\n\n    return createQuestionIdsFromBank(\n      bank: bank,\n      questionCount: questionCount,\n      seed: seed,\n    );\n  }\n\n  static List<String> createQuestionIdsFromBank({\n    required QuestionBank bank,\n    required int questionCount,\n    required int seed,\n  }) {\n    if (!LiveDuelMatchmakingPolicy.supportsQuestionCount(\n      questionCount,\n    )) {\n      throw const LiveDuelQuestionSetException(\n        'Canlı düello soru sayısı geçersiz.',\n      );\n    }\n\n    final random = Random(seed);\n    final targets = difficultyTargetsForCount(questionCount);\n\n    final categories = bank.questionsByCategory.entries\n        .where((entry) => entry.value.isNotEmpty)\n        .map((entry) => entry.key)\n        .where(\n          (category) =>\n              category >= 0 &&\n              category < GameCategory.values.length,\n        )\n        .toList(growable: true)\n      ..sort();\n\n    final requiredCategoryCount = min(\n      questionCount,\n      GameCategory.values.length,\n    );\n\n    if (categories.length < requiredCategoryCount) {\n      throw const LiveDuelQuestionSetException(\n        'Canlı düello için bütün kategorilerde yeterli soru yok.',\n      );\n    }\n\n    final difficultyPlan = <String>[\n      for (final entry in targets.entries)\n        ...List<String>.filled(entry.value, entry.key),\n    ]..shuffle(random);\n\n    final categoryPlan = <int>[];\n\n    while (categoryPlan.length < questionCount) {\n      final round = List<int>.from(categories)..shuffle(random);\n\n      if (categoryPlan.isNotEmpty &&\n          round.length > 1 &&\n          round.first == categoryPlan.last) {\n        final swapIndex = round.indexWhere(\n          (category) => category != categoryPlan.last,\n        );\n        final first = round.first;\n        round[0] = round[swapIndex];\n        round[swapIndex] = first;\n      }\n\n      final remaining = questionCount - categoryPlan.length;\n      categoryPlan.addAll(round.take(remaining));\n    }\n\n    final selected = <QuizQuestion>[];\n    final usedIds = <String>{};\n    final usedFamilies = <String>{};\n\n    for (var index = 0; index < questionCount; index++) {\n      final targetCategory = categoryPlan[index];\n      final targetDifficulty = difficultyPlan[index];\n      final categoryQuestions =\n          bank.questionsByCategory[targetCategory] ??\n              const <QuizQuestion>[];\n\n      var candidates = categoryQuestions\n          .where(\n            (question) =>\n                question.difficulty == targetDifficulty &&\n                !usedIds.contains(question.id) &&\n                !usedFamilies.contains(\n                  QuestionBank.questionFamilyKey(question.text),\n                ),\n          )\n          .toList(growable: true);\n\n      if (candidates.isEmpty) {\n        candidates = categoryQuestions\n            .where(\n              (question) =>\n                  question.difficulty == targetDifficulty &&\n                  !usedIds.contains(question.id),\n            )\n            .toList(growable: true);\n      }\n\n      if (candidates.isEmpty) {\n        throw LiveDuelQuestionSetException(\n          '$targetCategory kategorisinde '\n          '$targetDifficulty seviyesinde yeterli soru yok.',\n        );\n      }\n\n      candidates.sort(\n        (first, second) => first.id.compareTo(second.id),\n      );\n\n      final chosen =\n          candidates[random.nextInt(candidates.length)];\n\n      selected.add(chosen);\n      usedIds.add(chosen.id);\n      usedFamilies.add(\n        QuestionBank.questionFamilyKey(chosen.text),\n      );\n    }\n\n    final actualDifficultyCounts = <String, int>{\n      'Kolay': 0,\n      'Orta': 0,\n      'Zor': 0,\n    };\n    final actualCategoryCounts = <int, int>{};\n\n    for (final question in selected) {\n      actualDifficultyCounts[question.difficulty] =\n          (actualDifficultyCounts[question.difficulty] ?? 0) + 1;\n      actualCategoryCounts[question.categoryIndex] =\n          (actualCategoryCounts[question.categoryIndex] ?? 0) + 1;\n    }\n\n    for (final entry in targets.entries) {\n      if (actualDifficultyCounts[entry.key] != entry.value) {\n        throw const LiveDuelQuestionSetException(\n          'Canlı düello zorluk dağılımı oluşturulamadı.',\n        );\n      }\n    }\n\n    if (actualCategoryCounts.length != requiredCategoryCount) {\n      throw const LiveDuelQuestionSetException(\n        'Canlı düello kategori dağılımı oluşturulamadı.',\n      );\n    }\n\n    final categoryValues =\n        actualCategoryCounts.values.toList(growable: false);\n    final minCategoryCount = categoryValues.reduce(min);\n    final maxCategoryCount = categoryValues.reduce(max);\n\n    if (maxCategoryCount - minCategoryCount > 1) {\n      throw const LiveDuelQuestionSetException(\n        'Canlı düello kategorileri dengeli dağıtılamadı.',\n      );\n    }\n\n    for (var index = 1; index < selected.length; index++) {\n      if (selected[index - 1].categoryIndex ==\n          selected[index].categoryIndex) {\n        throw const LiveDuelQuestionSetException(\n          'Canlı düello soru sırası karıştırılamadı.',\n        );\n      }\n    }\n\n    final ids = selected\n        .map((question) => question.id)\n        .toList(growable: false);\n\n    if (ids.length != questionCount ||\n        ids.toSet().length != questionCount) {\n      throw const LiveDuelQuestionSetException(\n        'Ortak soru listesi oluşturulamadı.',\n      );\n    }\n\n    return List<String>.unmodifiable(ids);\n  }\n\n  static Future<LiveDuelQuestionSet> resolveQuestionIds(\n    List<String> questionIds,\n  ) async {\n    final bank = await QuestionBank.load();\n\n    return resolveQuestionIdsFromBank(\n      bank: bank,\n      questionIds: questionIds,\n    );\n  }\n\n  static LiveDuelQuestionSet resolveQuestionIdsFromBank({\n    required QuestionBank bank,\n    required List<String> questionIds,\n  }) {\n    if (!LiveDuelMatchmakingPolicy.supportsQuestionCount(\n      questionIds.length,\n    )) {\n      throw const LiveDuelQuestionSetException(\n        'Maç soru listesi geçersiz.',\n      );\n    }\n\n    if (questionIds.toSet().length != questionIds.length) {\n      throw const LiveDuelQuestionSetException(\n        'Maç soru listesinde tekrar var.',\n      );\n    }\n\n    final byId = <String, QuizQuestion>{\n      for (final question\n          in bank.questionsByCategory.values.expand(\n        (questions) => questions,\n      ))\n        question.id: question,\n    };\n\n    final questions = <QuizQuestion>[];\n\n    for (final id in questionIds) {\n      final question = byId[id];\n\n      if (question == null) {\n        throw LiveDuelQuestionSetException(\n          'Maç sorusu cihazda bulunamadı: $id',\n        );\n      }\n\n      questions.add(question);\n    }\n\n    return LiveDuelQuestionSet(\n      questionIds: List<String>.unmodifiable(questionIds),\n      questions: List<QuizQuestion>.unmodifiable(questions),\n    );\n  }\n\n  static int seedForMatch({\n    required String matchId,\n    required String firstPlayerUid,\n    required String secondPlayerUid,\n  }) {\n    final players = <String>[\n      firstPlayerUid,\n      secondPlayerUid,\n    ]..sort();\n\n    final source = '$matchId|${players.join('|')}';\n    var hash = 0x811C9DC5;\n\n    for (final unit in source.codeUnits) {\n      hash ^= unit;\n      hash = (hash * 0x01000193) & 0x7FFFFFFF;\n    }\n\n    return hash;\n  }\n\n  static List<String> questionIdsFromMatchData(\n    Map<String, dynamic> data,\n  ) {\n    final raw = data['questionIds'];\n\n    if (raw is! List) {\n      throw const LiveDuelQuestionSetException(\n        'Maçın soru listesi bulunamadı.',\n      );\n    }\n\n    return raw\n        .map((item) => item.toString())\n        .toList(growable: false);\n  }\n}\n"
NEW_TEST = "import 'package:bilgi_rotasi/main.dart';\nimport 'package:flutter_test/flutter_test.dart';\n\nQuizQuestion createQuestion({\n  required String id,\n  required int category,\n  required String difficulty,\n}) {\n  return QuizQuestion(\n    id: id,\n    categoryIndex: category,\n    text: 'Benzersiz bilgi sorusu $id',\n    options: const <String>['A', 'B', 'C', 'D'],\n    answerIndex: 0,\n    difficulty: difficulty,\n    explanation: '',\n  );\n}\n\nQuestionBank createBank() {\n  const difficulties = <String>[\n    'Kolay',\n    'Orta',\n    'Zor',\n  ];\n\n  return QuestionBank(<int, List<QuizQuestion>>{\n    for (var category = 0; category < 6; category++)\n      category: <QuizQuestion>[\n        for (final difficulty in difficulties)\n          for (var index = 0; index < 20; index++)\n            createQuestion(\n              id: 'q_${category}_${difficulty}_$index',\n              category: category,\n              difficulty: difficulty,\n            ),\n      ],\n  });\n}\n\nMap<String, int> difficultyCounts(\n  List<QuizQuestion> questions,\n) {\n  final counts = <String, int>{\n    'Kolay': 0,\n    'Orta': 0,\n    'Zor': 0,\n  };\n\n  for (final question in questions) {\n    counts[question.difficulty] =\n        (counts[question.difficulty] ?? 0) + 1;\n  }\n\n  return counts;\n}\n\nvoid expectBalancedCategories(\n  List<QuizQuestion> questions,\n) {\n  final counts = <int, int>{};\n\n  for (final question in questions) {\n    counts[question.categoryIndex] =\n        (counts[question.categoryIndex] ?? 0) + 1;\n  }\n\n  expect(counts.length, 6);\n\n  final values = counts.values.toList(growable: false);\n  final highest = values.reduce(\n    (first, second) => first > second ? first : second,\n  );\n  final lowest = values.reduce(\n    (first, second) => first < second ? first : second,\n  );\n  expect(highest - lowest, lessThanOrEqualTo(1));\n\n  for (var index = 1; index < questions.length; index++) {\n    expect(\n      questions[index - 1].categoryIndex,\n      isNot(questions[index].categoryIndex),\n    );\n  }\n}\n\nvoid main() {\n  group('Canlı düello ortak soru sistemi', () {\n    test('aynı tohum aynı soru sırasını üretir', () {\n      final bank = createBank();\n\n      final first =\n          LiveDuelQuestionSetService.createQuestionIdsFromBank(\n        bank: bank,\n        questionCount: 10,\n        seed: 1905,\n      );\n\n      final second =\n          LiveDuelQuestionSetService.createQuestionIdsFromBank(\n        bank: bank,\n        questionCount: 10,\n        seed: 1905,\n      );\n\n      expect(second, first);\n      expect(first.length, 10);\n      expect(first.toSet().length, 10);\n    });\n\n    test('10 soru 5 kolay 3 orta 2 zor olur', () {\n      final bank = createBank();\n      final ids =\n          LiveDuelQuestionSetService.createQuestionIdsFromBank(\n        bank: bank,\n        questionCount: 10,\n        seed: 2026,\n      );\n      final set =\n          LiveDuelQuestionSetService.resolveQuestionIdsFromBank(\n        bank: bank,\n        questionIds: ids,\n      );\n\n      expect(\n        difficultyCounts(set.questions),\n        const <String, int>{\n          'Kolay': 5,\n          'Orta': 3,\n          'Zor': 2,\n        },\n      );\n      expectBalancedCategories(set.questions);\n    });\n\n    test('20 ve 30 soruda aynı oran korunur', () {\n      final bank = createBank();\n\n      final expectations = <int, Map<String, int>>{\n        20: const <String, int>{\n          'Kolay': 10,\n          'Orta': 6,\n          'Zor': 4,\n        },\n        30: const <String, int>{\n          'Kolay': 15,\n          'Orta': 9,\n          'Zor': 6,\n        },\n      };\n\n      for (final entry in expectations.entries) {\n        final ids =\n            LiveDuelQuestionSetService.createQuestionIdsFromBank(\n          bank: bank,\n          questionCount: entry.key,\n          seed: 3000 + entry.key,\n        );\n        final set =\n            LiveDuelQuestionSetService.resolveQuestionIdsFromBank(\n          bank: bank,\n          questionIds: ids,\n        );\n\n        expect(difficultyCounts(set.questions), entry.value);\n        expectBalancedCategories(set.questions);\n      }\n    });\n\n    test('kimlikler aynı sırayla sorulara çevrilir', () {\n      final bank = createBank();\n\n      final ids =\n          LiveDuelQuestionSetService.createQuestionIdsFromBank(\n        bank: bank,\n        questionCount: 10,\n        seed: 2027,\n      );\n\n      final set =\n          LiveDuelQuestionSetService.resolveQuestionIdsFromBank(\n        bank: bank,\n        questionIds: ids,\n      );\n\n      expect(\n        set.questions\n            .map((question) => question.id)\n            .toList(),\n        ids,\n      );\n    });\n\n    test('maç tohumu oyuncu sırasından etkilenmez', () {\n      final first =\n          LiveDuelQuestionSetService.seedForMatch(\n        matchId: 'match-1',\n        firstPlayerUid: 'levent',\n        secondPlayerUid: 'emel',\n      );\n\n      final second =\n          LiveDuelQuestionSetService.seedForMatch(\n        matchId: 'match-1',\n        firstPlayerUid: 'emel',\n        secondPlayerUid: 'levent',\n      );\n\n      expect(second, first);\n    });\n\n    test('yalnızca güncel soru planı sürümü devam ettirilir', () {\n      expect(\n        LiveDuelQuestionSetService.currentVersion,\n        2,\n      );\n      expect(\n        LiveDuelQuestionSetService\n            .supportsQuestionSetVersion(2),\n        isTrue,\n      );\n      expect(\n        LiveDuelQuestionSetService\n            .supportsQuestionSetVersion(1),\n        isFalse,\n      );\n    });\n  });\n}\n"
STATUS_MD = "# Bilgi Rotası – Proje Durumu\n\n## Son Sürüm\n\n**1.58.0+79**\n\n## Son Tamamlanan İş\n\nCanlı Düello karışık kategori ve sabit zorluk dağılımı tamamlandı.\n\n- 10 soruluk maçlar: 5 Kolay, 3 Orta, 2 Zor.\n- 20 soruluk maçlar: 10 Kolay, 6 Orta, 4 Zor.\n- 30 soruluk maçlar: 15 Kolay, 9 Orta, 6 Zor.\n- Altı kategori maç boyunca dengeli dağıtılıyor.\n- Aynı kategori art arda getirilmiyor.\n- Aynı maç tohumu iki cihazda aynı soru sırasını üretmeye devam ediyor.\n- Soru planı sürümü 2'ye çıkarıldı.\n- Eski soru planıyla oluşturulmuş yarım maçlar yeni sürümde\n  devam kartına alınmıyor.\n- Firestore kuralları `bilgi-rotasi-f255d` projesinde yayında.\n- Canlı Düello Oyna menüsünden erişilebilir durumda.\n\n## Sıradaki İş\n\nCanlı Düello gerçek iki cihaz testi:\n\n- Yeni 1.58.0+79 APK'yı iki telefona kurma\n- 10 soruda 5/3/2 zorluk dağılımını doğrulama\n- Altı kategorinin karışık geldiğini doğrulama\n- 20 ve 30 soruluk maçları doğrulama\n- 30 saniye arka plan ve geri dönüş testi\n- 60 saniye sonunda hükmen sonuç testi\n- Bilinçli ayrılma testi\n- Yarım maça dönüş testi\n- BR ve lig sonucunu iki hesapta doğrulama\n- İstemci cevap doğruluğunu sunucu tarafında güçlendirme\n\n## Dokunulmaması Gerekenler\n\n- `assets/questions.json` içindeki doğrulanmış soru bankası\n- Mevcut Google giriş ve hesap silme sistemi\n- Çalışan bulut kayıt sistemi\n- Çalışan normal oyun modları\n- Firestore koleksiyon adları geçiş planı olmadan değiştirilmemeli\n\n## Kullanılan Çalışma Yöntemi\n\n- Geliştirme GitHub Codespaces üzerinden yapılıyor.\n- Kullanıcı çoğunlukla telefondan çalışıyor.\n- Paketler ZIP içinde Python kurulum dosyası olarak hazırlanmalı.\n- ZIP GitHub ana klasörüne yüklenip Codespaces'te pull edilerek kurulmalı.\n- Her paket analiz, ilgili test ve RC2 kalite kapısından geçmeli.\n- Testler tek tek ve `--concurrency=1` ile çalıştırılmalı.\n- Her paketin sonunda bu durum dosyası güncellenmeli.\n\n## Bilinen Durumlar\n\n- Toplam soru sayısı: **6710**\n- Firestore kuralları Firebase projesine başarıyla dağıtıldı.\n- Gerçek iki telefonla uçtan uca test devam ediyor.\n- İstemci cevap doğruluğunu gönderiyor; sunucu tarafı soru doğrulaması\n  yayın öncesinde güçlendirilmeli.\n\n## Son Başarılı Canlı Düello Aşamaları\n\n1. BR ve lig altyapısı\n2. Otomatik eşleştirme kuyruğu\n3. Canlı Düello giriş ve rakip arama ekranları\n4. Rakip bulundu ve 3-2-1 ekranı\n5. Ortak soru kimlikleri\n6. Cevap ve canlı ilerleme altyapısı\n7. Oynanabilir soru ekranı\n8. Canlı skor ve ilerleme çubukları\n9. Maç sonu sonuç ekranı\n10. Atomik maç sonucu\n11. Tek seferlik BR ve lig güncellemesi\n12. Bulut profil ve idempotent sonuç kaydı\n13. Bağlantı durumu ve 60 saniyelik yeniden bağlanma\n14. Hükmen galibiyet ve yenilgi\n15. Yarım kalan maça geri dönme\n16. Firestore kurallarının gerçek projeye dağıtılması\n17. Oyna menüsüne Canlı Düello girişi\n18. Karışık kategori ve sabit zorluk dağılımı\n"


def run(
    args: list[str],
    *,
    check: bool = True,
) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(
    text: str,
    old: str,
    new: str,
    label: str,
) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: beklenen metin {count} kez bulundu."
        )
    return text.replace(old, new, 1)


def remove_known_temp_files() -> None:
    for name in (
        "firebase-debug.log",
        "FIREBASE_GIRIS_LINKI.txt",
        "000_FIREBASE_GIRIS_LINKI.txt",
    ):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start() -> None:
    remove_known_temp_files()

    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )

    allowed = {
        f"?? {INSTALLER_NAME}",
    }
    unexpected = [
        line
        for line in result.stdout.splitlines()
        if line.strip() and line.strip() not in allowed
    ]

    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def write_question_files() -> None:
    (REPO / "lib/live_duel_questions.dart").write_text(
        NEW_QUESTIONS,
        encoding="utf-8",
    )
    (REPO / "test/live_duel_questions_test.dart").write_text(
        NEW_TEST,
        encoding="utf-8",
    )
    (REPO / "BILGI_ROTASI_DURUM.md").write_text(
        STATUS_MD,
        encoding="utf-8",
    )


def patch_matchmaking() -> None:
    path = REPO / "lib/live_duel_matchmaking.dart"
    text = path.read_text(encoding="utf-8")
    text = replace_once(
        text,
        "'questionSetVersion': 1,",
        "'questionSetVersion': "
        "LiveDuelQuestionSetService.currentVersion,",
        "Soru planı sürümü",
    )
    path.write_text(text, encoding="utf-8")


def patch_resume_filter() -> None:
    path = REPO / "lib/live_duel_connection.dart"
    text = path.read_text(encoding="utf-8")

    old = """      if (data['resultProcessed'] == true || data['status'] == 'completed') {
        continue;
      }

      final questionCount = (data['questionCount'] as num?)?.toInt() ?? 0;
"""

    new = """      if (data['resultProcessed'] == true ||
          data['status'] == 'completed') {
        continue;
      }

      if (!LiveDuelQuestionSetService
          .supportsQuestionSetVersion(
        data['questionSetVersion'],
      )) {
        continue;
      }

      final questionCount =
          (data['questionCount'] as num?)?.toInt() ?? 0;
"""

    text = replace_once(
        text,
        old,
        new,
        "Eski soru planını devam listesinden çıkarma",
    )
    path.write_text(text, encoding="utf-8")


def patch_versions() -> None:
    pubspec = REPO / "pubspec.yaml"
    text = pubspec.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"version: {OLD_VERSION}",
        f"version: {NEW_VERSION}",
        "pubspec sürümü",
    )
    pubspec.write_text(text, encoding="utf-8")

    build_info = REPO / "lib/app_build_info.dart"
    text = build_info.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"static const String versionName = '{OLD_VERSION_NAME}';",
        f"static const String versionName = '{NEW_VERSION_NAME}';",
        "uygulama sürümü",
    )
    text = replace_once(
        text,
        f"static const int buildNumber = {OLD_BUILD};",
        f"static const int buildNumber = {NEW_BUILD};",
        "uygulama yapı numarası",
    )
    build_info.write_text(text, encoding="utf-8")

    gate = REPO / "tools/rc1_quality_gate.py"
    text = gate.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f'EXPECTED_VERSION = "{OLD_VERSION}"',
        f'EXPECTED_VERSION = "{NEW_VERSION}"',
        "kalite kapısı sürümü",
    )
    gate.write_text(text, encoding="utf-8")

    workflow = REPO / ".github/workflows/android-apk.yml"
    text = workflow.read_text(encoding="utf-8")

    if OLD_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions güncel sürüm satırı bulunamadı."
        )
    text = text.replace(OLD_VERSION, NEW_VERSION)

    if OLD_ARTIFACT_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions artifact sürümü bulunamadı."
        )
    text = text.replace(
        OLD_ARTIFACT_VERSION,
        NEW_ARTIFACT_VERSION,
    )

    workflow.write_text(text, encoding="utf-8")


def analyze() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)

    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/live_duel_questions.dart",
        "lib/live_duel_matchmaking.dart",
        "lib/live_duel_connection.dart",
        "lib/app_build_info.dart",
        "test/live_duel_questions_test.dart",
    ]

    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )

    output = (result.stdout + result.stderr).splitlines()
    blocking = [
        line
        for line in output
        if line.startswith("ERROR|")
        or line.startswith("WARNING|")
    ]
    info_count = sum(
        line.startswith("INFO|") for line in output
    )

    print(
        f"Analiz: {len(blocking)} hata/uyarı, "
        f"{info_count} bilgi notu."
    )

    if blocking:
        print("\n".join(blocking[:30]))
        raise RuntimeError(
            "Dart analizi hata veya uyarı verdi."
        )


def run_tests() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)

    tests = [
        "test/live_duel_questions_test.dart",
        "test/live_duel_matchmaking_test.dart",
        "test/live_duel_connection_test.dart",
        "test/live_duel_play_screen_test.dart",
        "test/rc1_quality_gate_test.dart",
    ]

    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]

        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print(
            "Test ilk denemede geçmedi; "
            "önbellek temizlenip bir kez daha deneniyor."
        )
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])

        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")


def cleanup_package_files() -> None:
    remove_known_temp_files()

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ZIP_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if tracked:
            run(["git", "rm", "-f", ZIP_NAME])
        else:
            archive.unlink()


def rollback() -> None:
    subprocess.run(
        ["git", "reset", "--hard", "HEAD"],
        cwd=REPO,
        check=False,
    )


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()

        print("1/5 Karışık soru dağılımı uygulanıyor...")
        write_question_files()
        patch_matchmaking()
        patch_resume_filter()
        patch_versions()

        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "lib/live_duel_questions.dart",
            "lib/live_duel_matchmaking.dart",
            "lib/live_duel_connection.dart",
            "lib/app_build_info.dart",
            "test/live_duel_questions_test.dart",
        ])

        analyze()
        run_tests()

        print("\n4/5 RC2 kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        cleanup_package_files()

        print("\n5/5 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])

        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError(
                "Kaydedilecek değişiklik bulunamadı."
            )

        run([
            "git",
            "commit",
            "-m",
            "Canli duello soru dagilimini karistir",
        ])
        run(["git", "push", "origin", "main"])

        print("\n" + "=" * 60)
        print("TAMAMLANDI")
        print("=" * 60)
        run(["git", "log", "-1", "--oneline"])
        print(
            "GitHub Actions yeni 1.58.0+79 APK ve AAB "
            "derlemesini otomatik başlatacak."
        )
        return 0

    except Exception as error:
        print(f"\nHATA: {error}")
        print(
            "Değişiklikler güvenli biçimde geri alınıyor..."
        )
        rollback()
        print(
            f"Paket geri alındı; {INSTALLER_NAME} "
            "dosyasıyla tekrar denenebilir."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
