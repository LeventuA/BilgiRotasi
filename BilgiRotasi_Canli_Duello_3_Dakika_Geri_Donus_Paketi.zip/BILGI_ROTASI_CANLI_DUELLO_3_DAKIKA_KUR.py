#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
ZIP_NAME = "BilgiRotasi_Canli_Duello_3_Dakika_Geri_Donus_Paketi.zip"
INSTALLER_NAME = "BILGI_ROTASI_CANLI_DUELLO_3_DAKIKA_KUR.py"

OLD_VERSION = "1.60.0+81"
NEW_VERSION = "1.61.0+82"
OLD_VERSION_NAME = "1.60.0"
NEW_VERSION_NAME = "1.61.0"
OLD_BUILD = "81"
NEW_BUILD = "82"
OLD_ARTIFACT_VERSION = "1.60.0-81"
NEW_ARTIFACT_VERSION = "1.61.0-82"

STATUS_MD = "# Bilgi Rotası – Proje Durumu\n\n## Son Sürüm\n\n**1.61.0+82**\n\n## Son Tamamlanan İş\n\nCanlı Düello arka plan geri dönüş süresi iyileştirildi.\n\n- Uygulama kısa süreliğine arka plana geçtiğinde verilen geri dönüş süresi\n  60 saniyeden **3 dakikaya** çıkarıldı.\n- Mesajlaşma, kısa telefon görüşmesi veya uygulamalar arası geçiş yüzünden\n  maçın gereksiz yere hükmen kaybedilmesi azaltıldı.\n- Rakip ekranda kalan süreyi saniye saniye görmeye devam ediyor.\n- **Ayrıl ve yenilgiyi kabul et** seçeneği hâlâ anında hükmen sonuç üretiyor.\n- Firestore güvenlik kuralındaki azami geri dönüş süresi 190 saniyeye\n  çıkarıldı.\n- 3 dakikalık tolerans için otomatik testler eklendi.\n- Lig ve Sıralama merkezi çalışır durumda.\n\n## Sıradaki İş\n\n- Firestore kurallarını `bilgi-rotasi-f255d` projesine yeniden dağıtma\n- Yeni 1.61.0+82 APK'yı iki telefona kurma\n- Bir telefonu 2 dakika arka planda tutup geri dönme testi\n- Bir telefonu 3 dakika 10 saniye arka planda tutup hükmen sonuç testi\n- 20 ve 30 soruluk Canlı Düello testlerine devam etme\n\n## Dokunulmaması Gerekenler\n\n- `assets/questions.json` içindeki doğrulanmış soru bankası\n- Mevcut Google giriş ve hesap silme sistemi\n- Çalışan bulut kayıt sistemi\n- Çalışan normal oyun modları\n- Firestore koleksiyon adları geçiş planı olmadan değiştirilmemeli\n\n## Bilinen Durumlar\n\n- Toplam soru sayısı: **6710**\n- Sıralama yalnızca Google hesabıyla giriş yapan oyuncuları kapsar.\n- Bilinçli ayrılma ile geçici arka plan durumu ayrı davranır.\n"
EXTRA_TEST = "\n    test('geri dönüş politikası üç dakikadır', () {\n      expect(\n        LiveDuelConnectionPolicy.reconnectGrace,\n        const Duration(minutes: 3),\n      );\n    });\n\n    test('iki dakika arka planda kalan oyuncu korunur', () {\n      final now = DateTime.utc(2026, 7, 26, 12);\n\n      final loser = LiveDuelConnectionPolicy.forfeitLoser(\n        playerUids: const <String>['levent', 'emel'],\n        presences: <LiveDuelPresence>[\n          presence(\n            uid: 'levent',\n            state: LiveDuelPresenceState.active,\n            now: now,\n            connected: true,\n          ),\n          presence(\n            uid: 'emel',\n            state: LiveDuelPresenceState.background,\n            now: now.subtract(const Duration(minutes: 2)),\n            grace: const Duration(minutes: 3),\n          ),\n        ],\n        now: now,\n      );\n\n      expect(loser, isNull);\n    });\n\n    test('üç dakikayı aşan oyuncu hükmen yenilir', () {\n      final now = DateTime.utc(2026, 7, 26, 12);\n\n      final loser = LiveDuelConnectionPolicy.forfeitLoser(\n        playerUids: const <String>['levent', 'emel'],\n        presences: <LiveDuelPresence>[\n          presence(\n            uid: 'levent',\n            state: LiveDuelPresenceState.active,\n            now: now,\n            connected: true,\n          ),\n          presence(\n            uid: 'emel',\n            state: LiveDuelPresenceState.background,\n            now: now.subtract(\n              const Duration(minutes: 3, seconds: 10),\n            ),\n            grace: const Duration(minutes: 3),\n          ),\n        ],\n        now: now,\n      );\n\n      expect(loser, 'emel');\n    });\n"


def run(
    args: list[str],
    *,
    check: bool = True,
) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(
    text: str,
    old: str,
    new: str,
    label: str,
) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: beklenen metin {count} kez bulundu."
        )
    return text.replace(old, new, 1)


def remove_known_temp_files() -> None:
    for name in (
        "firebase-debug.log",
        "FIREBASE_GIRIS_LINKI.txt",
        "000_FIREBASE_GIRIS_LINKI.txt",
    ):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start() -> None:
    remove_known_temp_files()

    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )

    allowed = {f"?? {INSTALLER_NAME}"}
    unexpected = [
        line
        for line in result.stdout.splitlines()
        if line.strip() and line.strip() not in allowed
    ]

    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def patch_connection_policy() -> None:
    path = REPO / "lib/live_duel_connection.dart"
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "static const Duration reconnectGrace = "
        "Duration(seconds: 60);",
        "static const Duration reconnectGrace = "
        "Duration(minutes: 3);",
        "Geri dönüş süresi",
    )

    path.write_text(text, encoding="utf-8")


def patch_firestore_rules() -> None:
    path = REPO / "firestore.rules"
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "request.time + duration.value(70, 's')",
        "request.time + duration.value(190, 's')",
        "Firestore geri dönüş üst sınırı",
    )

    path.write_text(text, encoding="utf-8")


def patch_connection_tests() -> None:
    path = REPO / "test/live_duel_connection_test.dart"
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "now: now.subtract(const Duration(minutes: 2)),\n"
        "            grace: const Duration(seconds: 60),",
        "now: now.subtract("
        "const Duration(minutes: 3, seconds: 10)),\n"
        "            grace: const Duration(minutes: 3),",
        "Eski süre dolumu testi",
    )

    anchor = """    test('maçtan ayrılan oyuncu anında hükmen yenilir', () {
"""

    if "geri dönüş politikası üç dakikadır" not in text:
        text = replace_once(
            text,
            anchor,
            EXTRA_TEST + "\n" + anchor,
            "Üç dakikalık bağlantı testleri",
        )

    path.write_text(text, encoding="utf-8")


def patch_versions() -> None:
    pubspec = REPO / "pubspec.yaml"
    text = pubspec.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"version: {OLD_VERSION}",
        f"version: {NEW_VERSION}",
        "pubspec sürümü",
    )
    pubspec.write_text(text, encoding="utf-8")

    build_info = REPO / "lib/app_build_info.dart"
    text = build_info.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"static const String versionName = '{OLD_VERSION_NAME}';",
        f"static const String versionName = '{NEW_VERSION_NAME}';",
        "uygulama sürümü",
    )
    text = replace_once(
        text,
        f"static const int buildNumber = {OLD_BUILD};",
        f"static const int buildNumber = {NEW_BUILD};",
        "uygulama yapı numarası",
    )
    build_info.write_text(text, encoding="utf-8")

    gate = REPO / "tools/rc1_quality_gate.py"
    text = gate.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f'EXPECTED_VERSION = "{OLD_VERSION}"',
        f'EXPECTED_VERSION = "{NEW_VERSION}"',
        "Kalite kapısı sürümü",
    )
    gate.write_text(text, encoding="utf-8")

    workflow = REPO / ".github/workflows/android-apk.yml"
    text = workflow.read_text(encoding="utf-8")

    if OLD_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions güncel sürüm satırı bulunamadı."
        )
    text = text.replace(OLD_VERSION, NEW_VERSION)

    if OLD_ARTIFACT_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions artifact sürümü bulunamadı."
        )
    text = text.replace(
        OLD_ARTIFACT_VERSION,
        NEW_ARTIFACT_VERSION,
    )

    workflow.write_text(text, encoding="utf-8")


def write_status() -> None:
    (REPO / "BILGI_ROTASI_DURUM.md").write_text(
        STATUS_MD,
        encoding="utf-8",
    )


def analyze() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)

    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/live_duel_connection.dart",
        "lib/live_duel_play_screen.dart",
        "lib/app_build_info.dart",
        "test/live_duel_connection_test.dart",
    ]

    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )

    output = (result.stdout + result.stderr).splitlines()
    blocking = [
        line
        for line in output
        if line.startswith("ERROR|")
        or line.startswith("WARNING|")
    ]
    info_count = sum(
        line.startswith("INFO|") for line in output
    )

    print(
        f"Analiz: {len(blocking)} hata/uyarı, "
        f"{info_count} bilgi notu."
    )

    if blocking:
        print("\n".join(blocking[:40]))
        raise RuntimeError(
            "Dart analizi hata veya uyarı verdi."
        )


def run_tests() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)

    tests = [
        "test/live_duel_connection_test.dart",
        "test/live_duel_play_screen_test.dart",
        "test/live_duel_result_test.dart",
        "test/rc1_quality_gate_test.dart",
    ]

    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]

        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print(
            "Test ilk denemede geçmedi; "
            "önbellek temizlenip bir kez daha deneniyor."
        )
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])

        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")


def cleanup_package_files() -> None:
    remove_known_temp_files()

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ZIP_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if tracked:
            run(["git", "rm", "-f", ZIP_NAME])
        else:
            archive.unlink()


def rollback() -> None:
    subprocess.run(
        ["git", "reset", "--hard", "HEAD"],
        cwd=REPO,
        check=False,
    )


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()

        print("1/5 Üç dakikalık geri dönüş süresi uygulanıyor...")
        patch_connection_policy()
        patch_firestore_rules()
        patch_connection_tests()
        patch_versions()
        write_status()

        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "lib/live_duel_connection.dart",
            "lib/app_build_info.dart",
            "test/live_duel_connection_test.dart",
        ])

        analyze()
        run_tests()

        print("\n4/5 RC2 kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        cleanup_package_files()

        print("\n5/5 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])

        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError(
                "Kaydedilecek değişiklik bulunamadı."
            )

        run([
            "git",
            "commit",
            "-m",
            "Canli duello geri donus suresini uzat",
        ])
        run(["git", "push", "origin", "main"])

        print("\n" + "=" * 60)
        print("TAMAMLANDI")
        print("=" * 60)
        run(["git", "log", "-1", "--oneline"])
        print(
            "GitHub Actions yeni 1.61.0+82 APK ve AAB "
            "derlemesini otomatik başlatacak."
        )
        print(
            "NOT: Güncellenen Firestore kuralları Cloud Shell "
            "üzerinden yeniden dağıtılmalıdır."
        )
        return 0

    except Exception as error:
        print(f"\nHATA: {error}")
        print(
            "Değişiklikler güvenli biçimde geri alınıyor..."
        )
        rollback()
        print(
            f"Paket geri alındı; {INSTALLER_NAME} "
            "dosyasıyla tekrar denenebilir."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
