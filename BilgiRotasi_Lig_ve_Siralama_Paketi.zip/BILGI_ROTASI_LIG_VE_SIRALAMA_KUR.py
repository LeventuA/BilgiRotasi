#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
ZIP_NAME = "BilgiRotasi_Lig_ve_Siralama_Paketi.zip"
INSTALLER_NAME = "BILGI_ROTASI_LIG_VE_SIRALAMA_KUR.py"

OLD_VERSION = "1.59.0+80"
NEW_VERSION = "1.60.0+81"
OLD_VERSION_NAME = "1.59.0"
NEW_VERSION_NAME = "1.60.0"
OLD_BUILD = "80"
NEW_BUILD = "81"
OLD_ARTIFACT_VERSION = "1.59.0-80"
NEW_ARTIFACT_VERSION = "1.60.0-81"

LEADERBOARD_DART = "part of 'main.dart';\n\nclass LiveDuelLeaderboardEntry {\n  const LiveDuelLeaderboardEntry({\n    required this.uid,\n    required this.displayName,\n    required this.rating,\n    required this.matchesPlayed,\n    required this.wins,\n    required this.losses,\n    required this.draws,\n    required this.bestWinStreak,\n    required this.highestRating,\n    this.updatedAt,\n  });\n\n  final String uid;\n  final String displayName;\n  final int rating;\n  final int matchesPlayed;\n  final int wins;\n  final int losses;\n  final int draws;\n  final int bestWinStreak;\n  final int highestRating;\n  final DateTime? updatedAt;\n\n  BrLeague get league => BrLeagueResolver.fromRating(rating);\n\n  double get winRate {\n    if (matchesPlayed == 0) return 0;\n    return wins / matchesPlayed;\n  }\n\n  factory LiveDuelLeaderboardEntry.fromSnapshot(\n    QueryDocumentSnapshot<Map<String, dynamic>> snapshot,\n  ) {\n    final data = snapshot.data();\n    final rawUpdatedAt = data['updatedAt'];\n\n    return LiveDuelLeaderboardEntry(\n      uid: data['uid']?.toString() ?? snapshot.id,\n      displayName:\n          data['displayName']?.toString().trim().isNotEmpty == true\n              ? data['displayName'].toString().trim()\n              : 'Bilgi Yolcusu',\n      rating: max(0, (data['rating'] as num?)?.toInt() ?? 1000),\n      matchesPlayed: max(\n        0,\n        (data['matchesPlayed'] as num?)?.toInt() ?? 0,\n      ),\n      wins: max(0, (data['wins'] as num?)?.toInt() ?? 0),\n      losses: max(0, (data['losses'] as num?)?.toInt() ?? 0),\n      draws: max(0, (data['draws'] as num?)?.toInt() ?? 0),\n      bestWinStreak: max(\n        0,\n        (data['bestWinStreak'] as num?)?.toInt() ?? 0,\n      ),\n      highestRating: max(\n        0,\n        (data['highestRating'] as num?)?.toInt() ?? 1000,\n      ),\n      updatedAt:\n          rawUpdatedAt is Timestamp ? rawUpdatedAt.toDate() : null,\n    );\n  }\n}\n\nclass LiveDuelLeaderboardSnapshot {\n  const LiveDuelLeaderboardSnapshot({\n    required this.profile,\n    required this.leaders,\n    this.ownRank,\n    this.errorMessage,\n  });\n\n  final LiveDuelProfile profile;\n  final List<LiveDuelLeaderboardEntry> leaders;\n  final int? ownRank;\n  final String? errorMessage;\n}\n\nclass LiveDuelLeaderboardPresentation {\n  LiveDuelLeaderboardPresentation._();\n\n  static double leagueProgress(int rating) {\n    final league = BrLeagueResolver.fromRating(rating);\n    final next = league.nextThreshold;\n\n    if (next == null) return 1;\n\n    final range = next - league.minimumRating;\n    if (range <= 0) return 1;\n\n    return ((rating - league.minimumRating) / range)\n        .clamp(0.0, 1.0)\n        .toDouble();\n  }\n\n  static String nextLeagueLabel(int rating) {\n    final league = BrLeagueResolver.fromRating(rating);\n    final next = league.nextThreshold;\n\n    if (next == null) {\n      return 'En yüksek ligdesin';\n    }\n\n    final nextLeague = BrLeague.values[league.index + 1];\n    final remaining = max(0, next - rating);\n\n    return '${nextLeague.emoji} ${nextLeague.title} ligine '\n        '$remaining BR kaldı';\n  }\n\n  static int winRatePercent({\n    required int wins,\n    required int matchesPlayed,\n  }) {\n    if (matchesPlayed <= 0) return 0;\n    return ((wins / matchesPlayed) * 100).round();\n  }\n\n  static String rankLabel(int? rank) {\n    if (rank == null || rank <= 0) return '—';\n    return '#$rank';\n  }\n}\n\nclass LiveDuelLeaderboardService {\n  LiveDuelLeaderboardService._();\n\n  static FirebaseFirestore get _firestore =>\n      FirebaseFirestore.instance;\n\n  static CollectionReference<Map<String, dynamic>>\n      get _leaderboard =>\n          _firestore.collection('live_duel_leaderboard');\n\n  static String _displayName(User user) {\n    final firebaseName = user.displayName?.trim();\n    final localName =\n        AppPreferencesService.current.defaultPlayerName.trim();\n\n    var name =\n        firebaseName != null && firebaseName.isNotEmpty\n            ? firebaseName\n            : localName.isNotEmpty\n            ? localName\n            : 'Bilgi Yolcusu';\n\n    name = name.replaceAll(RegExp(r'\\s+'), ' ').trim();\n\n    if (name.length > 40) {\n      name = name.substring(0, 40);\n    }\n\n    return name;\n  }\n\n  static Future<void> publish(\n    LiveDuelProfile profile,\n  ) async {\n    final user = FirebaseAuth.instance.currentUser;\n    if (user == null) return;\n\n    try {\n      await _leaderboard.doc(user.uid).set(\n        <String, dynamic>{\n          'uid': user.uid,\n          'displayName': _displayName(user),\n          'rating': profile.rating,\n          'matchesPlayed': profile.matchesPlayed,\n          'wins': profile.wins,\n          'losses': profile.losses,\n          'draws': profile.draws,\n          'bestWinStreak': profile.bestWinStreak,\n          'highestRating': profile.highestRating,\n          'updatedAt': FieldValue.serverTimestamp(),\n          'appVersion': AppBuildInfo.version,\n        },\n        SetOptions(merge: false),\n      );\n    } catch (_) {\n      // Sıralama yayını kişisel BR profilini engellememeli.\n    }\n  }\n\n  static Future<LiveDuelLeaderboardSnapshot> load() async {\n    final profile = await LiveDuelProfileService.load();\n    final user = FirebaseAuth.instance.currentUser;\n\n    if (user == null) {\n      return LiveDuelLeaderboardSnapshot(\n        profile: profile,\n        leaders: const <LiveDuelLeaderboardEntry>[],\n        errorMessage:\n            'Lig sıralaması için Google hesabıyla giriş yapmalısın.',\n      );\n    }\n\n    await publish(profile);\n\n    try {\n      final results = await Future.wait<Object>([\n        _leaderboard\n            .orderBy('rating', descending: true)\n            .limit(100)\n            .get(),\n        _leaderboard\n            .where('rating', isGreaterThan: profile.rating)\n            .count()\n            .get(),\n      ]);\n\n      final leadersSnapshot =\n          results[0]\n              as QuerySnapshot<Map<String, dynamic>>;\n      final rankSnapshot =\n          results[1] as AggregateQuerySnapshot;\n\n      final leaders = leadersSnapshot.docs\n          .map(LiveDuelLeaderboardEntry.fromSnapshot)\n          .toList(growable: false);\n\n      return LiveDuelLeaderboardSnapshot(\n        profile: profile,\n        leaders: leaders,\n        ownRank: rankSnapshot.count + 1,\n      );\n    } on FirebaseException catch (error) {\n      return LiveDuelLeaderboardSnapshot(\n        profile: profile,\n        leaders: const <LiveDuelLeaderboardEntry>[],\n        errorMessage:\n            error.code == 'permission-denied'\n                ? 'Lig tablosu güvenlik kuralları henüz '\n                    'yayınlanmamış olabilir.'\n                : 'Lig tablosu şu anda yüklenemedi.',\n      );\n    } catch (_) {\n      return LiveDuelLeaderboardSnapshot(\n        profile: profile,\n        leaders: const <LiveDuelLeaderboardEntry>[],\n        errorMessage: 'Lig tablosu şu anda yüklenemedi.',\n      );\n    }\n  }\n}\n\nclass LiveDuelLeaderboardScreen extends StatefulWidget {\n  const LiveDuelLeaderboardScreen({super.key});\n\n  @override\n  State<LiveDuelLeaderboardScreen> createState() =>\n      _LiveDuelLeaderboardScreenState();\n}\n\nclass _LiveDuelLeaderboardScreenState\n    extends State<LiveDuelLeaderboardScreen> {\n  late Future<LiveDuelLeaderboardSnapshot> _future;\n\n  @override\n  void initState() {\n    super.initState();\n    _reload();\n  }\n\n  void _reload() {\n    _future = LiveDuelLeaderboardService.load();\n  }\n\n  Future<void> _refresh() async {\n    setState(_reload);\n    await _future;\n  }\n\n  @override\n  Widget build(BuildContext context) {\n    return Scaffold(\n      appBar: AppBar(\n        title: const Text('Lig ve Sıralama'),\n      ),\n      body: FutureBuilder<LiveDuelLeaderboardSnapshot>(\n        future: _future,\n        builder: (context, snapshot) {\n          if (snapshot.connectionState ==\n              ConnectionState.waiting) {\n            return const Center(\n              child: CircularProgressIndicator(),\n            );\n          }\n\n          final data = snapshot.data;\n          if (data == null) {\n            return _errorBody(\n              'Lig bilgileri yüklenemedi.',\n            );\n          }\n\n          return RefreshIndicator(\n            onRefresh: _refresh,\n            child: ListView(\n              physics:\n                  const AlwaysScrollableScrollPhysics(),\n              padding: const EdgeInsets.fromLTRB(\n                16,\n                16,\n                16,\n                28,\n              ),\n              children: <Widget>[\n                _profileCard(data),\n                const SizedBox(height: 14),\n                _statisticsCard(data.profile),\n                const SizedBox(height: 20),\n                _sectionTitle(\n                  emoji: '🏆',\n                  title: 'İlk 100 Oyuncu',\n                  subtitle:\n                      'BR puanına göre genel sıralama',\n                ),\n                const SizedBox(height: 10),\n                if (data.errorMessage != null)\n                  _messageCard(data.errorMessage!)\n                else if (data.leaders.isEmpty)\n                  _messageCard(\n                    'Henüz sıralamaya giren oyuncu yok.',\n                  )\n                else\n                  _leaderboardCard(data.leaders),\n                const SizedBox(height: 20),\n                _sectionTitle(\n                  emoji: '🕘',\n                  title: 'Son Maçların',\n                  subtitle:\n                      'En son 10 dereceli düello',\n                ),\n                const SizedBox(height: 10),\n                _recentMatchesCard(data.profile),\n              ],\n            ),\n          );\n        },\n      ),\n    );\n  }\n\n  Widget _errorBody(String message) {\n    return Center(\n      child: Padding(\n        padding: const EdgeInsets.all(24),\n        child: Text(\n          message,\n          textAlign: TextAlign.center,\n        ),\n      ),\n    );\n  }\n\n  Widget _profileCard(\n    LiveDuelLeaderboardSnapshot data,\n  ) {\n    final profile = data.profile;\n    final league = profile.league;\n    final progress =\n        LiveDuelLeaderboardPresentation.leagueProgress(\n          profile.rating,\n        );\n\n    return Container(\n      padding: const EdgeInsets.all(20),\n      decoration: BoxDecoration(\n        borderRadius: BorderRadius.circular(26),\n        gradient: const LinearGradient(\n          begin: Alignment.topLeft,\n          end: Alignment.bottomRight,\n          colors: <Color>[\n            Color(0xFF0F766E),\n            Color(0xFF4338CA),\n          ],\n        ),\n        border: Border.all(\n          color: const Color(0x99FFE082),\n        ),\n        boxShadow: const <BoxShadow>[\n          BoxShadow(\n            color: Color(0x44000000),\n            blurRadius: 18,\n            offset: Offset(0, 9),\n          ),\n        ],\n      ),\n      child: Column(\n        crossAxisAlignment:\n            CrossAxisAlignment.stretch,\n        children: <Widget>[\n          Row(\n            children: <Widget>[\n              Container(\n                width: 64,\n                height: 64,\n                alignment: Alignment.center,\n                decoration: BoxDecoration(\n                  shape: BoxShape.circle,\n                  color: const Color(0x22FFFFFF),\n                  border: Border.all(\n                    color:\n                        const Color(0xAAFFE082),\n                    width: 2,\n                  ),\n                ),\n                child: Text(\n                  league.emoji,\n                  style:\n                      const TextStyle(fontSize: 32),\n                ),\n              ),\n              const SizedBox(width: 14),\n              Expanded(\n                child: Column(\n                  crossAxisAlignment:\n                      CrossAxisAlignment.start,\n                  children: <Widget>[\n                    const Text(\n                      'REKABET PROFİLİN',\n                      style: TextStyle(\n                        color: Color(0xFFFFE082),\n                        fontSize: 11,\n                        letterSpacing: 1,\n                        fontWeight: FontWeight.w900,\n                      ),\n                    ),\n                    const SizedBox(height: 4),\n                    Text(\n                      '${league.title} Ligi',\n                      style: const TextStyle(\n                        color: Colors.white,\n                        fontSize: 25,\n                        fontWeight: FontWeight.w900,\n                      ),\n                    ),\n                    Text(\n                      '${profile.rating} BR',\n                      style: const TextStyle(\n                        color: Color(0xFFD8F7F1),\n                        fontSize: 16,\n                        fontWeight: FontWeight.w800,\n                      ),\n                    ),\n                  ],\n                ),\n              ),\n              Column(\n                children: <Widget>[\n                  const Text(\n                    'SIRAN',\n                    style: TextStyle(\n                      color: Color(0xFFD8CCEA),\n                      fontSize: 10,\n                      fontWeight: FontWeight.w800,\n                    ),\n                  ),\n                  Text(\n                    LiveDuelLeaderboardPresentation\n                        .rankLabel(data.ownRank),\n                    style: const TextStyle(\n                      color: Colors.white,\n                      fontSize: 25,\n                      fontWeight: FontWeight.w900,\n                    ),\n                  ),\n                ],\n              ),\n            ],\n          ),\n          const SizedBox(height: 18),\n          ClipRRect(\n            borderRadius: BorderRadius.circular(999),\n            child: LinearProgressIndicator(\n              value: progress,\n              minHeight: 11,\n              backgroundColor:\n                  const Color(0x33FFFFFF),\n              color: const Color(0xFFFFE082),\n            ),\n          ),\n          const SizedBox(height: 8),\n          Text(\n            LiveDuelLeaderboardPresentation\n                .nextLeagueLabel(profile.rating),\n            style: const TextStyle(\n              color: Colors.white,\n              fontSize: 13,\n              fontWeight: FontWeight.w700,\n            ),\n          ),\n          if (!profile.placementsComplete) ...[\n            const SizedBox(height: 12),\n            Container(\n              padding: const EdgeInsets.all(11),\n              decoration: BoxDecoration(\n                color: const Color(0x20FFFFFF),\n                borderRadius: BorderRadius.circular(14),\n              ),\n              child: Text(\n                'Yerleştirme maçları: '\n                '${profile.placementMatchesRemaining} kaldı. '\n                'İlk 5 maçta BR değişimi daha hızlıdır.',\n                style: const TextStyle(\n                  color: Color(0xFFEDE7F6),\n                  fontSize: 12,\n                  fontWeight: FontWeight.w600,\n                ),\n              ),\n            ),\n          ],\n        ],\n      ),\n    );\n  }\n\n  Widget _statisticsCard(LiveDuelProfile profile) {\n    final winRate =\n        LiveDuelLeaderboardPresentation.winRatePercent(\n          wins: profile.wins,\n          matchesPlayed: profile.matchesPlayed,\n        );\n\n    return Card(\n      child: Padding(\n        padding: const EdgeInsets.all(16),\n        child: Column(\n          children: <Widget>[\n            Row(\n              children: <Widget>[\n                Expanded(\n                  child: _stat(\n                    'Maç',\n                    profile.matchesPlayed.toString(),\n                  ),\n                ),\n                Expanded(\n                  child: _stat(\n                    'Galibiyet',\n                    profile.wins.toString(),\n                  ),\n                ),\n                Expanded(\n                  child: _stat(\n                    'Mağlubiyet',\n                    profile.losses.toString(),\n                  ),\n                ),\n                Expanded(\n                  child: _stat(\n                    'Kazanma',\n                    '%$winRate',\n                  ),\n                ),\n              ],\n            ),\n            const Divider(height: 28),\n            Row(\n              children: <Widget>[\n                Expanded(\n                  child: _stat(\n                    'Beraberlik',\n                    profile.draws.toString(),\n                  ),\n                ),\n                Expanded(\n                  child: _stat(\n                    'En iyi seri',\n                    profile.bestWinStreak.toString(),\n                  ),\n                ),\n                Expanded(\n                  child: _stat(\n                    'En yüksek BR',\n                    profile.highestRating.toString(),\n                  ),\n                ),\n              ],\n            ),\n          ],\n        ),\n      ),\n    );\n  }\n\n  Widget _stat(String label, String value) {\n    return Column(\n      children: <Widget>[\n        Text(\n          value,\n          style: const TextStyle(\n            fontSize: 19,\n            fontWeight: FontWeight.w900,\n          ),\n        ),\n        const SizedBox(height: 3),\n        Text(\n          label,\n          textAlign: TextAlign.center,\n          style: const TextStyle(\n            fontSize: 10,\n            fontWeight: FontWeight.w600,\n          ),\n        ),\n      ],\n    );\n  }\n\n  Widget _sectionTitle({\n    required String emoji,\n    required String title,\n    required String subtitle,\n  }) {\n    return Row(\n      children: <Widget>[\n        Text(\n          emoji,\n          style: const TextStyle(fontSize: 26),\n        ),\n        const SizedBox(width: 10),\n        Expanded(\n          child: Column(\n            crossAxisAlignment:\n                CrossAxisAlignment.start,\n            children: <Widget>[\n              Text(\n                title,\n                style: const TextStyle(\n                  fontSize: 20,\n                  fontWeight: FontWeight.w900,\n                ),\n              ),\n              Text(\n                subtitle,\n                style: const TextStyle(\n                  fontSize: 12,\n                ),\n              ),\n            ],\n          ),\n        ),\n      ],\n    );\n  }\n\n  Widget _messageCard(String message) {\n    return Card(\n      child: Padding(\n        padding: const EdgeInsets.all(18),\n        child: Text(\n          message,\n          textAlign: TextAlign.center,\n        ),\n      ),\n    );\n  }\n\n  Widget _leaderboardCard(\n    List<LiveDuelLeaderboardEntry> leaders,\n  ) {\n    final ownUid =\n        FirebaseAuth.instance.currentUser?.uid;\n\n    return Card(\n      clipBehavior: Clip.antiAlias,\n      child: Column(\n        children: <Widget>[\n          for (\n            var index = 0;\n            index < leaders.length;\n            index++\n          )\n            _leaderRow(\n              rank: index + 1,\n              entry: leaders[index],\n              isOwn: leaders[index].uid == ownUid,\n              showDivider:\n                  index < leaders.length - 1,\n            ),\n        ],\n      ),\n    );\n  }\n\n  Widget _leaderRow({\n    required int rank,\n    required LiveDuelLeaderboardEntry entry,\n    required bool isOwn,\n    required bool showDivider,\n  }) {\n    final rankText = switch (rank) {\n      1 => '🥇',\n      2 => '🥈',\n      3 => '🥉',\n      _ => '#$rank',\n    };\n\n    return Container(\n      decoration: BoxDecoration(\n        color:\n            isOwn\n                ? const Color(0x2232B8A6)\n                : Colors.transparent,\n        border:\n            showDivider\n                ? const Border(\n                  bottom: BorderSide(\n                    color: Color(0x16000000),\n                  ),\n                )\n                : null,\n      ),\n      padding: const EdgeInsets.symmetric(\n        horizontal: 14,\n        vertical: 12,\n      ),\n      child: Row(\n        children: <Widget>[\n          SizedBox(\n            width: 40,\n            child: Text(\n              rankText,\n              textAlign: TextAlign.center,\n              style: TextStyle(\n                fontSize: rank <= 3 ? 23 : 13,\n                fontWeight: FontWeight.w900,\n              ),\n            ),\n          ),\n          const SizedBox(width: 9),\n          Text(\n            entry.league.emoji,\n            style: const TextStyle(fontSize: 22),\n          ),\n          const SizedBox(width: 9),\n          Expanded(\n            child: Column(\n              crossAxisAlignment:\n                  CrossAxisAlignment.start,\n              children: <Widget>[\n                Text(\n                  isOwn\n                      ? '${entry.displayName} • Sen'\n                      : entry.displayName,\n                  maxLines: 1,\n                  overflow: TextOverflow.ellipsis,\n                  style: const TextStyle(\n                    fontWeight: FontWeight.w900,\n                  ),\n                ),\n                Text(\n                  '${entry.matchesPlayed} maç • '\n                  '${entry.wins}G ${entry.losses}M',\n                  style: const TextStyle(\n                    fontSize: 11,\n                  ),\n                ),\n              ],\n            ),\n          ),\n          const SizedBox(width: 8),\n          Column(\n            crossAxisAlignment:\n                CrossAxisAlignment.end,\n            children: <Widget>[\n              Text(\n                '${entry.rating} BR',\n                style: const TextStyle(\n                  fontWeight: FontWeight.w900,\n                ),\n              ),\n              Text(\n                entry.league.title,\n                style: const TextStyle(\n                  fontSize: 10,\n                ),\n              ),\n            ],\n          ),\n        ],\n      ),\n    );\n  }\n\n  Widget _recentMatchesCard(\n    LiveDuelProfile profile,\n  ) {\n    if (profile.recentMatches.isEmpty) {\n      return _messageCard(\n        'Henüz tamamlanmış bir düello yok.',\n      );\n    }\n\n    return Card(\n      clipBehavior: Clip.antiAlias,\n      child: Column(\n        children: <Widget>[\n          for (\n            var index = 0;\n            index < profile.recentMatches.length;\n            index++\n          )\n            _recentMatchRow(\n              profile.recentMatches[index],\n              showDivider:\n                  index <\n                  profile.recentMatches.length - 1,\n            ),\n        ],\n      ),\n    );\n  }\n\n  Widget _recentMatchRow(\n    LiveDuelRecentMatch match, {\n    required bool showDivider,\n  }) {\n    final resultText = switch (match.result) {\n      LiveDuelResult.win => 'Galibiyet',\n      LiveDuelResult.loss => 'Mağlubiyet',\n      LiveDuelResult.draw => 'Beraberlik',\n    };\n    final resultEmoji = switch (match.result) {\n      LiveDuelResult.win => '✅',\n      LiveDuelResult.loss => '❌',\n      LiveDuelResult.draw => '🤝',\n    };\n    final deltaPrefix =\n        match.ratingDelta > 0 ? '+' : '';\n    final date = match.playedAt.toLocal();\n\n    return Container(\n      decoration: BoxDecoration(\n        border:\n            showDivider\n                ? const Border(\n                  bottom: BorderSide(\n                    color: Color(0x16000000),\n                  ),\n                )\n                : null,\n      ),\n      padding: const EdgeInsets.symmetric(\n        horizontal: 15,\n        vertical: 13,\n      ),\n      child: Row(\n        children: <Widget>[\n          Text(\n            resultEmoji,\n            style: const TextStyle(fontSize: 23),\n          ),\n          const SizedBox(width: 11),\n          Expanded(\n            child: Column(\n              crossAxisAlignment:\n                  CrossAxisAlignment.start,\n              children: <Widget>[\n                Text(\n                  '$resultText • ${match.opponentName}',\n                  maxLines: 1,\n                  overflow: TextOverflow.ellipsis,\n                  style: const TextStyle(\n                    fontWeight: FontWeight.w900,\n                  ),\n                ),\n                Text(\n                  '${date.day.toString().padLeft(2, '0')}.'\n                  '${date.month.toString().padLeft(2, '0')}.'\n                  '${date.year}',\n                  style: const TextStyle(\n                    fontSize: 11,\n                  ),\n                ),\n              ],\n            ),\n          ),\n          Text(\n            '$deltaPrefix${match.ratingDelta} BR',\n            style: TextStyle(\n              fontWeight: FontWeight.w900,\n              color:\n                  match.ratingDelta >= 0\n                      ? const Color(0xFF0F766E)\n                      : const Color(0xFFB91C1C),\n            ),\n          ),\n        ],\n      ),\n    );\n  }\n}\n"
LEADERBOARD_TEST = 'import \'dart:io\';\n\nimport \'package:bilgi_rotasi/main.dart\';\nimport \'package:flutter_test/flutter_test.dart\';\n\nvoid main() {\n  group(\'Canlı Düello lig ve sıralama\', () {\n    test(\'lig ilerleme oranı eşiklere göre hesaplanır\', () {\n      expect(\n        LiveDuelLeaderboardPresentation.leagueProgress(1000),\n        0,\n      );\n      expect(\n        LiveDuelLeaderboardPresentation.leagueProgress(1200),\n        0.5,\n      );\n      expect(\n        LiveDuelLeaderboardPresentation.leagueProgress(3000),\n        1,\n      );\n    });\n\n    test(\'sonraki lig ve sıra metinleri doğru üretilir\', () {\n      expect(\n        LiveDuelLeaderboardPresentation.nextLeagueLabel(1200),\n        contains(\'200 BR kaldı\'),\n      );\n      expect(\n        LiveDuelLeaderboardPresentation.nextLeagueLabel(3000),\n        \'En yüksek ligdesin\',\n      );\n      expect(\n        LiveDuelLeaderboardPresentation.rankLabel(7),\n        \'#7\',\n      );\n      expect(\n        LiveDuelLeaderboardPresentation.rankLabel(null),\n        \'—\',\n      );\n    });\n\n    test(\'kazanma oranı hesaplanır\', () {\n      expect(\n        LiveDuelLeaderboardPresentation.winRatePercent(\n          wins: 7,\n          matchesPlayed: 10,\n        ),\n        70,\n      );\n      expect(\n        LiveDuelLeaderboardPresentation.winRatePercent(\n          wins: 0,\n          matchesPlayed: 0,\n        ),\n        0,\n      );\n    });\n\n    test(\'sıralama ekranı uygulamaya bağlıdır\', () {\n      final mainSource =\n          File(\'lib/main.dart\').readAsStringSync();\n      final duelSource =\n          File(\'lib/live_duel_screen.dart\')\n              .readAsStringSync();\n      final rules =\n          File(\'firestore.rules\').readAsStringSync();\n\n      expect(\n        mainSource,\n        contains("part \'live_duel_leaderboard.dart\';"),\n      );\n      expect(\n        duelSource,\n        contains(\'LiveDuelLeaderboardScreen\'),\n      );\n      expect(\n        duelSource,\n        contains(\'Lig ve Sıralama\'),\n      );\n      expect(\n        rules,\n        contains(\n          \'match /live_duel_leaderboard/{userId}\',\n        ),\n      );\n    });\n  });\n}\n'
STATUS_MD = "# Bilgi Rotası – Proje Durumu\n\n## Son Sürüm\n\n**1.60.0+81**\n\n## Son Tamamlanan İş\n\nCanlı Düello için Lig ve Sıralama merkezi eklendi.\n\n- Canlı Düello ekranına **Lig ve Sıralama** düğmesi eklendi.\n- Kullanıcının genel sırası ve güncel BR puanı gösteriliyor.\n- Sonraki lige kalan BR ve ilerleme çubuğu gösteriliyor.\n- Maç, galibiyet, mağlubiyet, beraberlik, kazanma oranı,\n  en iyi seri ve en yüksek BR istatistikleri gösteriliyor.\n- BR puanına göre ilk 100 oyuncu listeleniyor.\n- Kullanıcının kendi satırı sıralamada vurgulanıyor.\n- Son 10 dereceli maç ve BR değişimleri gösteriliyor.\n- Yalnızca güvenli rekabet istatistiklerini taşıyan\n  `live_duel_leaderboard` koleksiyonu eklendi.\n- Hesap silindiğinde sıralama kaydı da siliniyor.\n- Sıralama güvenlik kuralları eklendi.\n\n## Sıradaki İş\n\n- Firestore kurallarını `bilgi-rotasi-f255d` projesine dağıtma\n- Yeni 1.60.0+81 APK'yı iki telefona kurma\n- İki hesabın ilk 100 listesinde görünmesini doğrulama\n- Maç sonrasında BR, sıra ve son maçların yenilendiğini doğrulama\n- 20 ve 30 soruluk Canlı Düello testlerine devam etme\n\n## Dokunulmaması Gerekenler\n\n- `assets/questions.json` içindeki doğrulanmış soru bankası\n- Mevcut Google giriş ve hesap silme sistemi\n- Çalışan bulut kayıt sistemi\n- Çalışan normal oyun modları\n- Firestore koleksiyon adları geçiş planı olmadan değiştirilmemeli\n\n## Bilinen Durumlar\n\n- Toplam soru sayısı: **6710**\n- Sıralama yalnızca Google hesabıyla giriş yapan oyuncuları kapsar.\n- Sıralama belgesi, oyuncu Canlı Düello ekranını açtığında veya\n  maç sonucu kaydedildiğinde otomatik güncellenir.\n"


def run(
    args: list[str],
    *,
    check: bool = True,
) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(
    text: str,
    old: str,
    new: str,
    label: str,
) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: beklenen metin {count} kez bulundu."
        )
    return text.replace(old, new, 1)


def remove_known_temp_files() -> None:
    for name in (
        "firebase-debug.log",
        "FIREBASE_GIRIS_LINKI.txt",
        "000_FIREBASE_GIRIS_LINKI.txt",
    ):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start() -> None:
    remove_known_temp_files()

    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )

    allowed = {f"?? {INSTALLER_NAME}"}
    unexpected = [
        line
        for line in result.stdout.splitlines()
        if line.strip() and line.strip() not in allowed
    ]

    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def patch_main_parts() -> None:
    path = REPO / "lib/main.dart"
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "part 'live_duel_league.dart';\n"
        "part 'live_duel_matchmaking.dart';",
        "part 'live_duel_league.dart';\n"
        "part 'live_duel_leaderboard.dart';\n"
        "part 'live_duel_matchmaking.dart';",
        "Lig sıralama part bağlantısı",
    )

    path.write_text(text, encoding="utf-8")


def write_new_files() -> None:
    (REPO / "lib/live_duel_leaderboard.dart").write_text(
        LEADERBOARD_DART,
        encoding="utf-8",
    )
    (REPO / "test/live_duel_leaderboard_test.dart").write_text(
        LEADERBOARD_TEST,
        encoding="utf-8",
    )
    (REPO / "BILGI_ROTASI_DURUM.md").write_text(
        STATUS_MD,
        encoding="utf-8",
    )


def patch_profile_sync() -> None:
    path = REPO / "lib/live_duel_league.dart"
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "        await saveLocal(remote);\n"
        "        return remote;",
        "        await saveLocal(remote);\n"
        "        await LiveDuelLeaderboardService.publish(remote);\n"
        "        return remote;",
        "Uzak profil sıralama yayını",
    )

    text = replace_once(
        text,
        "      await reference.set(<String, dynamic>{\n"
        "        'liveDuelProfile': local.toJson(),\n"
        "        'liveDuelProfileUpdatedAt': FieldValue.serverTimestamp(),\n"
        "        'appVersion': AppBuildInfo.version,\n"
        "      }, SetOptions(merge: true));",
        "      await reference.set(<String, dynamic>{\n"
        "        'liveDuelProfile': local.toJson(),\n"
        "        'liveDuelProfileUpdatedAt': FieldValue.serverTimestamp(),\n"
        "        'appVersion': AppBuildInfo.version,\n"
        "      }, SetOptions(merge: true));\n"
        "      await LiveDuelLeaderboardService.publish(local);",
        "İlk profil sıralama yayını",
    )

    text = replace_once(
        text,
        "      await FirebaseFirestore.instance\n"
        "          .collection('users')\n"
        "          .doc(user.uid)\n"
        "          .set(<String, dynamic>{\n"
        "            'liveDuelProfile': profile.toJson(),\n"
        "            'liveDuelProfileUpdatedAt': FieldValue.serverTimestamp(),\n"
        "            'appVersion': AppBuildInfo.version,\n"
        "          }, SetOptions(merge: true));",
        "      await FirebaseFirestore.instance\n"
        "          .collection('users')\n"
        "          .doc(user.uid)\n"
        "          .set(<String, dynamic>{\n"
        "            'liveDuelProfile': profile.toJson(),\n"
        "            'liveDuelProfileUpdatedAt': FieldValue.serverTimestamp(),\n"
        "            'appVersion': AppBuildInfo.version,\n"
        "          }, SetOptions(merge: true));\n"
        "      await LiveDuelLeaderboardService.publish(profile);",
        "Maç sonucu sıralama yayını",
    )

    path.write_text(text, encoding="utf-8")


def patch_duel_screen() -> None:
    path = REPO / "lib/live_duel_screen.dart"
    text = path.read_text(encoding="utf-8")

    method_anchor = """  Future<void> _startMatchmaking() async {
"""

    method = """  Future<void> _openLeaderboard() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder:
            (context) =>
                const LiveDuelLeaderboardScreen(),
      ),
    );

    if (!mounted) return;
    await _loadProfile();
  }

"""

    text = replace_once(
        text,
        method_anchor,
        method + method_anchor,
        "Lig ekranı açma metodu",
    )

    card_anchor = """                            Text(
                              _profile.placementsComplete
                                  ? '${_profile.matchesPlayed} dereceli maç'
                                  : 'Yerleştirme maçları: '
                                      '${_profile.placementMatchesRemaining} kaldı',
                            ),
"""

    card_replacement = card_anchor + """                            const SizedBox(height: 14),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonalIcon(
                                onPressed: _openLeaderboard,
                                icon: const Icon(
                                  Icons.emoji_events_rounded,
                                ),
                                label: const Text(
                                  'Lig ve Sıralama',
                                ),
                              ),
                            ),
"""

    text = replace_once(
        text,
        card_anchor,
        card_replacement,
        "Canlı Düello lig kartı",
    )

    path.write_text(text, encoding="utf-8")


def patch_account_deletion() -> None:
    path = REPO / "lib/account_cloud.dart"
    text = path.read_text(encoding="utf-8")

    anchor = """      await _deleteLiveDuelResultClaims(user.uid);

      await _firestore!.collection('users').doc(user.uid).delete();
"""

    replacement = """      await _deleteLiveDuelResultClaims(user.uid);

      try {
        await _firestore!
            .collection('live_duel_leaderboard')
            .doc(user.uid)
            .delete();
      } catch (_) {
        // Eski kurallar sıralama silme işlemini engellese bile
        // hesap silme akışı devam etmelidir.
      }

      await _firestore!.collection('users').doc(user.uid).delete();
"""

    text = replace_once(
        text,
        anchor,
        replacement,
        "Hesap silerken sıralama temizliği",
    )

    path.write_text(text, encoding="utf-8")


def patch_firestore_rules() -> None:
    path = REPO / "firestore.rules"
    text = path.read_text(encoding="utf-8")

    function_anchor = """    function signedIn() {
      return request.auth != null;
    }

"""

    functions = """    function userDuelProfile(userId) {
      return get(
        /databases/$(database)/documents/users/$(userId)
      ).data.liveDuelProfile;
    }

    function validLeaderboardWrite(userId) {
      let profile = userDuelProfile(userId);

      return signedIn()
             && request.auth.uid == userId
             && profile is map
             && request.resource.data.keys().hasOnly([
               'uid',
               'displayName',
               'rating',
               'matchesPlayed',
               'wins',
               'losses',
               'draws',
               'bestWinStreak',
               'highestRating',
               'updatedAt',
               'appVersion'
             ])
             && request.resource.data.uid == userId
             && request.resource.data.displayName is string
             && request.resource.data.displayName.size() > 0
             && request.resource.data.displayName.size() <= 40
             && request.resource.data.rating == profile.rating
             && request.resource.data.matchesPlayed ==
                profile.matchesPlayed
             && request.resource.data.wins == profile.wins
             && request.resource.data.losses == profile.losses
             && request.resource.data.draws == profile.draws
             && request.resource.data.bestWinStreak ==
                profile.bestWinStreak
             && request.resource.data.highestRating ==
                profile.highestRating
             && request.resource.data.updatedAt == request.time
             && request.resource.data.appVersion is string;
    }

"""

    text = replace_once(
        text,
        function_anchor,
        function_anchor + functions,
        "Sıralama güvenlik fonksiyonları",
    )

    match_anchor = """    match /live_duel_queue/{userId} {
"""

    leaderboard_match = """    match /live_duel_leaderboard/{userId} {
      allow read: if signedIn();

      allow create, update: if validLeaderboardWrite(userId);

      allow delete: if signedIn()
                    && request.auth.uid == userId;
    }

"""

    text = replace_once(
        text,
        match_anchor,
        leaderboard_match + match_anchor,
        "Sıralama koleksiyonu kuralları",
    )

    path.write_text(text, encoding="utf-8")


def patch_versions() -> None:
    pubspec = REPO / "pubspec.yaml"
    text = pubspec.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"version: {OLD_VERSION}",
        f"version: {NEW_VERSION}",
        "pubspec sürümü",
    )
    pubspec.write_text(text, encoding="utf-8")

    build_info = REPO / "lib/app_build_info.dart"
    text = build_info.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"static const String versionName = '{OLD_VERSION_NAME}';",
        f"static const String versionName = '{NEW_VERSION_NAME}';",
        "uygulama sürümü",
    )
    text = replace_once(
        text,
        f"static const int buildNumber = {OLD_BUILD};",
        f"static const int buildNumber = {NEW_BUILD};",
        "uygulama yapı numarası",
    )
    build_info.write_text(text, encoding="utf-8")

    gate = REPO / "tools/rc1_quality_gate.py"
    text = gate.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f'EXPECTED_VERSION = "{OLD_VERSION}"',
        f'EXPECTED_VERSION = "{NEW_VERSION}"',
        "kalite kapısı sürümü",
    )
    gate.write_text(text, encoding="utf-8")

    workflow = REPO / ".github/workflows/android-apk.yml"
    text = workflow.read_text(encoding="utf-8")

    if OLD_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions güncel sürüm satırı bulunamadı."
        )
    text = text.replace(OLD_VERSION, NEW_VERSION)

    if OLD_ARTIFACT_VERSION not in text:
        raise RuntimeError(
            "GitHub Actions artifact sürümü bulunamadı."
        )
    text = text.replace(
        OLD_ARTIFACT_VERSION,
        NEW_ARTIFACT_VERSION,
    )

    workflow.write_text(text, encoding="utf-8")


def analyze() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)

    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/main.dart",
        "lib/live_duel_league.dart",
        "lib/live_duel_leaderboard.dart",
        "lib/live_duel_screen.dart",
        "lib/account_cloud.dart",
        "lib/app_build_info.dart",
        "test/live_duel_leaderboard_test.dart",
    ]

    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )

    output = (result.stdout + result.stderr).splitlines()
    blocking = [
        line
        for line in output
        if line.startswith("ERROR|")
        or line.startswith("WARNING|")
    ]
    info_count = sum(
        line.startswith("INFO|") for line in output
    )

    print(
        f"Analiz: {len(blocking)} hata/uyarı, "
        f"{info_count} bilgi notu."
    )

    if blocking:
        print("\n".join(blocking[:40]))
        raise RuntimeError(
            "Dart analizi hata veya uyarı verdi."
        )


def run_tests() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)

    tests = [
        "test/live_duel_leaderboard_test.dart",
        "test/live_duel_league_test.dart",
        "test/live_duel_screen_test.dart",
        "test/live_duel_result_test.dart",
        "test/rc1_quality_gate_test.dart",
    ]

    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]

        result = run(command, check=False)
        if result.returncode == 0:
            continue

        print(
            "Test ilk denemede geçmedi; "
            "önbellek temizlenip bir kez daha deneniyor."
        )
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])

        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")


def cleanup_package_files() -> None:
    remove_known_temp_files()

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ZIP_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if tracked:
            run(["git", "rm", "-f", ZIP_NAME])
        else:
            archive.unlink()


def rollback() -> None:
    subprocess.run(
        ["git", "reset", "--hard", "HEAD"],
        cwd=REPO,
        check=False,
    )


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()

        print("1/5 Lig ve sıralama merkezi uygulanıyor...")
        patch_main_parts()
        write_new_files()
        patch_profile_sync()
        patch_duel_screen()
        patch_account_deletion()
        patch_firestore_rules()
        patch_versions()

        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "lib/main.dart",
            "lib/live_duel_league.dart",
            "lib/live_duel_leaderboard.dart",
            "lib/live_duel_screen.dart",
            "lib/account_cloud.dart",
            "lib/app_build_info.dart",
            "test/live_duel_leaderboard_test.dart",
        ])

        analyze()
        run_tests()

        print("\n4/5 RC2 kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        cleanup_package_files()

        print("\n5/5 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])

        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError(
                "Kaydedilecek değişiklik bulunamadı."
            )

        run([
            "git",
            "commit",
            "-m",
            "Canli duello lig ve siralama merkezini ekle",
        ])
        run(["git", "push", "origin", "main"])

        print("\n" + "=" * 60)
        print("TAMAMLANDI")
        print("=" * 60)
        run(["git", "log", "-1", "--oneline"])
        print(
            "GitHub Actions yeni 1.60.0+81 APK ve AAB "
            "derlemesini otomatik başlatacak."
        )
        print(
            "NOT: Yeni sıralama kuralları Firebase Cloud Shell "
            "üzerinden ayrıca dağıtılmalıdır."
        )
        return 0

    except Exception as error:
        print(f"\nHATA: {error}")
        print(
            "Değişiklikler güvenli biçimde geri alınıyor..."
        )
        rollback()
        print(
            f"Paket geri alındı; {INSTALLER_NAME} "
            "dosyasıyla tekrar denenebilir."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
