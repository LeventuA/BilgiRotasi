#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

REPO = Path("/workspaces/BilgiRotasi")
ZIP_NAME = "BilgiRotasi_Canli_Duello_Sunucu_Dogrulamasi_Paketi.zip"
INSTALLER_NAME = "BILGI_ROTASI_CANLI_DUELLO_SUNUCU_DOGRULAMA_KUR.py"
PAYLOAD = REPO / "_br_server_validation_payload"

OLD_VERSION = "1.61.0+82"
NEW_VERSION = "1.62.0+83"
OLD_VERSION_NAME = "1.61.0"
NEW_VERSION_NAME = "1.62.0"
OLD_BUILD = "82"
NEW_BUILD = "83"
OLD_ARTIFACT_VERSION = "1.61.0-82"
NEW_ARTIFACT_VERSION = "1.62.0-83"


def run(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    print("$", " ".join(args), flush=True)
    return subprocess.run(args, cwd=REPO, check=check)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: beklenen metin {count} kez bulundu."
        )
    return text.replace(old, new, 1)


def remove_known_temp_files() -> None:
    for name in (
        "firebase-debug.log",
        "FIREBASE_GIRIS_LINKI.txt",
        "000_FIREBASE_GIRIS_LINKI.txt",
    ):
        path = REPO / name
        if path.exists():
            path.unlink()


def ensure_clean_start() -> None:
    remove_known_temp_files()
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPO,
        check=True,
        text=True,
        capture_output=True,
    )
    allowed = {
        f"?? {INSTALLER_NAME}",
        "?? _br_server_validation_payload/",
    }
    unexpected = [
        line for line in result.stdout.splitlines()
        if line.strip() and line.strip() not in allowed
    ]
    if unexpected:
        print("HATA: Çalışma alanında beklenmeyen değişiklik var:")
        print("\n".join(unexpected))
        raise RuntimeError("Önce çalışma alanı temizlenmeli.")


def patch_progress_model() -> None:
    path = REPO / "lib/live_duel_progress.dart"
    text = path.read_text(encoding="utf-8")

    text = replace_once(
        text,
        "    this.lastQuestionId,\n    this.updatedAt,",
        "    this.lastQuestionId,\n"
        "    this.lastSelectedOptionIndex,\n"
        "    this.updatedAt,",
        "İlerleme kurucusu",
    )
    text = replace_once(
        text,
        "  final String? lastQuestionId;\n"
        "  final DateTime? updatedAt;",
        "  final String? lastQuestionId;\n"
        "  final int? lastSelectedOptionIndex;\n"
        "  final DateTime? updatedAt;",
        "Seçilen şık alanı",
    )
    text = replace_once(
        text,
        "    'lastQuestionId': lastQuestionId,\n  };",
        "    'lastQuestionId': lastQuestionId,\n"
        "    'lastSelectedOptionIndex': lastSelectedOptionIndex,\n"
        "  };",
        "İlerleme JSON alanı",
    )
    text = replace_once(
        text,
        "      lastQuestionId: data['lastQuestionId']?.toString(),\n"
        "      updatedAt:",
        "      lastQuestionId: data['lastQuestionId']?.toString(),\n"
        "      lastSelectedOptionIndex:\n"
        "          (data['lastSelectedOptionIndex'] as num?)?.toInt(),\n"
        "      updatedAt:",
        "İlerleme okuma alanı",
    )
    text = replace_once(
        text,
        "    required String questionId,\n"
        "    required bool correct,\n"
        "    required int questionCount,",
        "    required String questionId,\n"
        "    required int selectedOptionIndex,\n"
        "    required bool correct,\n"
        "    required int questionCount,",
        "Hesaplayıcı şık parametresi",
    )
    text = replace_once(
        text,
        "    if (questionCount <= 0) {",
        "    if (selectedOptionIndex < 0) {\n"
        "      throw const LiveDuelProgressException(\n"
        "        'Seçilen şık geçersiz.',\n"
        "      );\n"
        "    }\n\n"
        "    if (questionCount <= 0) {",
        "Şık aralığı kontrolü",
    )
    text = replace_once(
        text,
        "      lastQuestionId: questionId,\n    );",
        "      lastQuestionId: questionId,\n"
        "      lastSelectedOptionIndex: selectedOptionIndex,\n"
        "    );",
        "Seçilen şıkkı ilerlemeye yazma",
    )

    old_signature = (
        "    required String matchId,\n"
        "    required String questionId,\n"
        "    required bool correct,\n"
        "  }) async {"
    )
    new_signature = (
        "    required String matchId,\n"
        "    required String questionId,\n"
        "    required int selectedOptionIndex,\n"
        "    required bool correct,\n"
        "  }) async {"
    )
    text = replace_once(
        text,
        old_signature,
        new_signature,
        "Cevap gönderme şık parametresi",
    )
    text = replace_once(
        text,
        "        questionId: questionId,\n"
        "        correct: correct,\n"
        "        questionCount: questionCount,",
        "        questionId: questionId,\n"
        "        selectedOptionIndex: selectedOptionIndex,\n"
        "        correct: correct,\n"
        "        questionCount: questionCount,",
        "Hesaplayıcıya şık aktarımı",
    )

    path.write_text(text, encoding="utf-8")


def patch_play_screen() -> None:
    path = REPO / "lib/live_duel_play_screen.dart"
    text = path.read_text(encoding="utf-8")
    text = replace_once(
        text,
        "        questionId: question.id,\n"
        "        correct: correct,",
        "        questionId: question.id,\n"
        "        selectedOptionIndex: optionIndex,\n"
        "        correct: correct,",
        "Soru ekranından şık gönderme",
    )
    path.write_text(text, encoding="utf-8")


def patch_firestore_rules() -> None:
    path = REPO / "firestore.rules"
    text = path.read_text(encoding="utf-8")

    helper_anchor = "    function duelPresenceExists(matchId, userId) {\n"
    helpers = """    function duelQuestionKey(questionId) {
      return get(
        /databases/$(database)/documents/live_duel_question_keys/$(questionId)
      );
    }

    function validInitialDuelProgress(matchId, userId) {
      let matchData = duelMatch(matchId).data;
      let next = request.resource.data;

      return request.auth.uid == userId
             && request.auth.uid in matchData.playerUids
             && matchData.get('resultProcessed', false) != true
             && next.keys().hasOnly([
               'uid',
               'currentQuestionIndex',
               'answeredCount',
               'correctCount',
               'wrongCount',
               'finished',
               'lastAnswerCorrect',
               'lastQuestionId',
               'lastSelectedOptionIndex',
               'updatedAt',
               'finishedAt'
             ])
             && next.uid == userId
             && next.currentQuestionIndex == 0
             && next.answeredCount == 0
             && next.correctCount == 0
             && next.wrongCount == 0
             && next.finished == false
             && next.lastAnswerCorrect == null
             && next.lastQuestionId == null
             && next.lastSelectedOptionIndex == null
             && next.updatedAt == request.time
             && next.finishedAt == null;
    }

    function validDuelProgressUpdate(matchId, userId) {
      let matchData = duelMatch(matchId).data;
      let previous = resource.data;
      let next = request.resource.data;
      let expectedQuestionId =
        matchData.questionIds[previous.answeredCount];
      let key = duelQuestionKey(expectedQuestionId).data;
      let answerCorrect =
        next.lastSelectedOptionIndex == key.answerIndex;

      return request.auth.uid == userId
             && request.auth.uid in matchData.playerUids
             && matchData.get('resultProcessed', false) != true
             && previous.finished == false
             && previous.answeredCount < matchData.questionCount
             && next.keys().hasOnly([
               'uid',
               'currentQuestionIndex',
               'answeredCount',
               'correctCount',
               'wrongCount',
               'finished',
               'lastAnswerCorrect',
               'lastQuestionId',
               'lastSelectedOptionIndex',
               'updatedAt',
               'finishedAt'
             ])
             && next.uid == userId
             && next.answeredCount == previous.answeredCount + 1
             && next.currentQuestionIndex == next.answeredCount
             && next.lastQuestionId == expectedQuestionId
             && key.answerIndex is int
             && key.optionCount is int
             && key.optionCount >= 2
             && next.lastSelectedOptionIndex is int
             && next.lastSelectedOptionIndex >= 0
             && next.lastSelectedOptionIndex < key.optionCount
             && next.lastAnswerCorrect == answerCorrect
             && next.correctCount ==
                previous.correctCount +
                (answerCorrect ? 1 : 0)
             && next.wrongCount ==
                previous.wrongCount +
                (answerCorrect ? 0 : 1)
             && next.correctCount + next.wrongCount ==
                next.answeredCount
             && next.finished ==
                (next.answeredCount == matchData.questionCount)
             && next.updatedAt == request.time
             && (
               (
                 next.finished == true
                 && next.finishedAt == request.time
               )
               ||
               (
                 next.finished == false
                 && next.finishedAt == null
               )
             )
             && next.diff(previous).affectedKeys().hasOnly([
               'currentQuestionIndex',
               'answeredCount',
               'correctCount',
               'wrongCount',
               'finished',
               'lastAnswerCorrect',
               'lastQuestionId',
               'lastSelectedOptionIndex',
               'updatedAt',
               'finishedAt'
             ]);
    }

"""
    text = replace_once(
        text,
        helper_anchor,
        helpers + helper_anchor,
        "Sunucu doğrulama fonksiyonları",
    )

    match_anchor = "    match /live_duel_matches/{matchId} {\n"
    private_match = """    match /live_duel_question_keys/{questionId} {
      allow read, write: if false;
    }

"""
    text = replace_once(
        text,
        match_anchor,
        private_match + match_anchor,
        "Özel cevap anahtarı koleksiyonu",
    )

    old_progress = """      match /progress/{userId} {
        allow read: if signedIn()
                    && request.auth.uid
                       in duelMatch(matchId).data.playerUids;

        allow create, update: if signedIn()
                              && request.auth.uid == userId
                              && request.resource.data.uid == userId
                              && request.resource.data.answeredCount >= 0
                              && request.resource.data.correctCount >= 0
                              && request.resource.data.wrongCount >= 0
                              && request.resource.data.answeredCount ==
                                 request.resource.data.correctCount +
                                 request.resource.data.wrongCount
                              && request.resource.data.currentQuestionIndex ==
                                 request.resource.data.answeredCount
                              && request.resource.data.answeredCount <=
                                 duelMatch(matchId).data.questionCount
                              && duelMatch(matchId).data
                                 .get('resultProcessed', false) != true;

        allow delete: if false;
      }
"""
    new_progress = """      match /progress/{userId} {
        allow read: if signedIn()
                    && request.auth.uid
                       in duelMatch(matchId).data.playerUids;

        allow create: if signedIn()
                      && validInitialDuelProgress(matchId, userId);

        allow update: if signedIn()
                      && validDuelProgressUpdate(matchId, userId);

        allow delete: if false;
      }
"""
    text = replace_once(
        text,
        old_progress,
        new_progress,
        "İlerleme güvenlik kuralları",
    )

    path.write_text(text, encoding="utf-8")


def copy_payloads() -> None:
    shutil.copy2(
        PAYLOAD / "live_duel_progress_test.dart",
        REPO / "test/live_duel_progress_test.dart",
    )
    shutil.copy2(
        PAYLOAD / "live_duel_server_validation_test.dart",
        REPO / "test/live_duel_server_validation_test.dart",
    )
    uploader = REPO / "tools/upload_live_duel_question_keys.py"
    shutil.copy2(
        PAYLOAD / "upload_live_duel_question_keys.py",
        uploader,
    )
    uploader.chmod(0o755)
    shutil.copy2(
        PAYLOAD / "BILGI_ROTASI_DURUM.md",
        REPO / "BILGI_ROTASI_DURUM.md",
    )


def patch_versions() -> None:
    pubspec = REPO / "pubspec.yaml"
    text = pubspec.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"version: {OLD_VERSION}",
        f"version: {NEW_VERSION}",
        "pubspec sürümü",
    )
    pubspec.write_text(text, encoding="utf-8")

    build_info = REPO / "lib/app_build_info.dart"
    text = build_info.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f"static const String versionName = '{OLD_VERSION_NAME}';",
        f"static const String versionName = '{NEW_VERSION_NAME}';",
        "uygulama sürümü",
    )
    text = replace_once(
        text,
        f"static const int buildNumber = {OLD_BUILD};",
        f"static const int buildNumber = {NEW_BUILD};",
        "yapı numarası",
    )
    build_info.write_text(text, encoding="utf-8")

    gate = REPO / "tools/rc1_quality_gate.py"
    text = gate.read_text(encoding="utf-8")
    text = replace_once(
        text,
        f'EXPECTED_VERSION = "{OLD_VERSION}"',
        f'EXPECTED_VERSION = "{NEW_VERSION}"',
        "kalite kapısı sürümü",
    )
    gate.write_text(text, encoding="utf-8")

    workflow = REPO / ".github/workflows/android-apk.yml"
    text = workflow.read_text(encoding="utf-8")
    if OLD_VERSION not in text:
        raise RuntimeError("Workflow uygulama sürümü bulunamadı.")
    text = text.replace(OLD_VERSION, NEW_VERSION)
    if OLD_ARTIFACT_VERSION not in text:
        raise RuntimeError("Workflow artifact sürümü bulunamadı.")
    text = text.replace(
        OLD_ARTIFACT_VERSION,
        NEW_ARTIFACT_VERSION,
    )
    workflow.write_text(text, encoding="utf-8")


def analyze() -> None:
    print("\n2/5 Dart analizi çalışıyor...", flush=True)
    command = [
        "/workspaces/flutter/bin/dart",
        "analyze",
        "--format",
        "machine",
        "lib/live_duel_progress.dart",
        "lib/live_duel_play_screen.dart",
        "lib/app_build_info.dart",
        "test/live_duel_progress_test.dart",
        "test/live_duel_server_validation_test.dart",
    ]
    result = subprocess.run(
        command,
        cwd=REPO,
        check=False,
        text=True,
        capture_output=True,
    )
    output = (result.stdout + result.stderr).splitlines()
    blocking = [
        line for line in output
        if line.startswith("ERROR|")
        or line.startswith("WARNING|")
    ]
    info_count = sum(line.startswith("INFO|") for line in output)
    print(
        f"Analiz: {len(blocking)} hata/uyarı, "
        f"{info_count} bilgi notu."
    )
    if blocking:
        print("\n".join(blocking[:40]))
        raise RuntimeError("Dart analizi hata veya uyarı verdi.")


def run_tests() -> None:
    print("\n3/5 Testler tek tek çalışıyor...", flush=True)
    tests = [
        "test/live_duel_progress_test.dart",
        "test/live_duel_server_validation_test.dart",
        "test/live_duel_play_screen_test.dart",
        "test/live_duel_result_test.dart",
        "test/rc1_quality_gate_test.dart",
    ]
    for test in tests:
        print(f"\nTEST: {test}", flush=True)
        command = [
            "/workspaces/flutter/bin/flutter",
            "test",
            test,
            "--concurrency=1",
            "--reporter",
            "expanded",
        ]
        result = run(command, check=False)
        if result.returncode == 0:
            continue
        shutil.rmtree(REPO / ".dart_tool", ignore_errors=True)
        shutil.rmtree(REPO / "build", ignore_errors=True)
        run(["/workspaces/flutter/bin/flutter", "pub", "get"])
        result = run(command, check=False)
        if result.returncode != 0:
            raise RuntimeError(f"Test başarısız: {test}")

    print("\nGerçek soru bankası doğrulanıyor...")
    run([
        "python3",
        "tools/upload_live_duel_question_keys.py",
        "--validate-only",
        "--expected-count",
        "6710",
    ])


def cleanup_package_files() -> None:
    remove_known_temp_files()
    if PAYLOAD.exists():
        shutil.rmtree(PAYLOAD)

    installer = REPO / INSTALLER_NAME
    if installer.exists():
        installer.unlink()

    archive = REPO / ZIP_NAME
    if archive.exists():
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", ZIP_NAME],
            cwd=REPO,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
        if tracked:
            run(["git", "rm", "-f", ZIP_NAME])
        else:
            archive.unlink()


def rollback() -> None:
    subprocess.run(
        ["git", "reset", "--hard", "HEAD"],
        cwd=REPO,
        check=False,
    )
    for path in (
        REPO / "test/live_duel_server_validation_test.dart",
        REPO / "tools/upload_live_duel_question_keys.py",
    ):
        if path.exists():
            path.unlink()


def main() -> int:
    if not REPO.is_dir():
        print("HATA: /workspaces/BilgiRotasi bulunamadı.")
        return 1

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        cwd=REPO,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for hook in ("post-checkout", "pre-push"):
        (REPO / ".git/hooks" / hook).unlink(missing_ok=True)

    try:
        ensure_clean_start()
        print("1/5 Sunucu doğrulamalı puan yazımı uygulanıyor...")
        patch_progress_model()
        patch_play_screen()
        patch_firestore_rules()
        copy_payloads()
        patch_versions()

        run([
            "/workspaces/flutter/bin/dart",
            "format",
            "lib/live_duel_progress.dart",
            "lib/live_duel_play_screen.dart",
            "lib/app_build_info.dart",
            "test/live_duel_progress_test.dart",
            "test/live_duel_server_validation_test.dart",
        ])

        analyze()
        run_tests()

        print("\n4/5 RC2 kalite kapısı çalışıyor...")
        run(["python3", "tools/rc1_quality_gate.py"])
        run(["git", "diff", "--check"])

        cleanup_package_files()

        print("\n5/5 Commit ve push yapılıyor...")
        run(["git", "add", "-A"])
        staged = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=REPO,
            check=False,
        )
        if staged.returncode == 0:
            raise RuntimeError("Kaydedilecek değişiklik bulunamadı.")

        run([
            "git",
            "commit",
            "-m",
            "Canli duello puan yazimini sunucuda dogrula",
        ])
        run(["git", "push", "origin", "main"])

        print("\n" + "=" * 60)
        print("TAMAMLANDI")
        print("=" * 60)
        run(["git", "log", "-1", "--oneline"])
        print(
            "GitHub Actions yeni 1.62.0+83 APK ve AAB "
            "derlemesini başlatacak."
        )
        print(
            "Cevap anahtarları yüklenmeden ve yeni APK kurulmadan "
            "Firestore kurallarını dağıtma."
        )
        return 0
    except Exception as error:
        print(f"\nHATA: {error}")
        print("Değişiklikler geri alınıyor...")
        rollback()
        print(
            f"Paket geri alındı; {INSTALLER_NAME} ile tekrar denenebilir."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
